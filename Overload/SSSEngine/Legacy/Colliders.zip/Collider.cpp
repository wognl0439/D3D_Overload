#include "Collider.h"
#include "Shader.h"
#include "Mesh.h"
#include "Device.h"
#include "GameObject.h"
#include "Component\RectCollider2D.h"
#include "Component\CircleCollider2D.h"
#include "Component\SphereCollider.h"
#include "CollisionVoxel2D.h"
#include "CollisionVoxel3D.h"
#include "Scene.h"
#include "Layer.h"
#include "TImerManager.h"
#include "Timer.h"
#include "Physics.h"
#include "Component\BoxCollider.h"
#include "CollisionManager.h"
#include "Transform.h"


SSS_USING

#ifdef _DEBUG
#include "RenderState.h"
#include "RenderManager.h"
#include "Material.h"
#include "ResourcesManager.h"
#include "Sampler.h"
#endif // _DEBUG



CCollider::CCollider()
{
	m_pActor = NULL;
	m_pShape = NULL;
	m_pPhysicsMaterial = NULL;

	GET_SINGLE(CCollisionManager)->GetPhysics()->createMaterial(0.5f, 0.5f, 0.5f);

	m_iBaseTypeHash = typeid(CCollider).hash_code();

#ifdef _DEBUG
	memset(m_pRenderState, 0, sizeof(CRenderState*) * RS_END);
	SetSampler();
	m_vColliderColor = Vector4::green;
#endif // _DEBUG

}

CCollider::CCollider(const CCollider & component) :
	CComponent(component)
{
	m_vLocalPosition = component.m_vLocalPosition;
#ifdef _DEBUG

	m_pShader = component.m_pShader;
	m_pMesh = component.m_pMesh;
	m_pLayout = component.m_pLayout;


	if (m_pShader)
		m_pShader->AddRef();

	if (m_pMesh)
		m_pMesh->AddRef();

#endif // _DEBUG

}

CCollider::~CCollider()
{

	if (m_pShape)
	{
		if (m_pShape->isReleasable())
		{
			m_pShape->release();
		}
	}

	if (m_pActor)
	{
		if (m_pActor->isReleasable())
		{
			m_pActor->release();
		}
	}

	if (m_pPhysicsMaterial)
	{
		if (m_pPhysicsMaterial->isReleasable())
		{
			m_pPhysicsMaterial->release();
		}
	}

	if (this == GET_SINGLE(CCollisionManager)->GetCoveredCollider())
	{
		GET_SINGLE(CCollisionManager)->ClearCoveredCollider();
	}


	{
		unordered_map<CCollider*, CCollider*>::iterator iter;
		unordered_map<CCollider*, CCollider*>::iterator iterEnd = m_mapCollision.end();
		for (iter = m_mapCollision.begin(); iter != iterEnd;++iter)
		{
			CGameObject* pTarget = iter->second->GetGameObject();
			pTarget->OnCollisionExit(this, NULL, 0);	
			(*iter).second->RemoveTargetFromCollisionList(this);
	
			SAFE_RELEASE(pTarget);
		}
	}

     m_pScene->RemoveCollider(this);
	{
		list<CCollisionVoxel2D*>::iterator iter;
		list<CCollisionVoxel2D*>::iterator iterEnd = m_CollisionVoxel2DList.end();

		for (iter = m_CollisionVoxel2DList.begin(); iter != iterEnd; ++iter)
		{
			(*iter)->Remove(this);
		}	
	}

	{
		list<CCollisionVoxel3D*>::iterator iter;
		list<CCollisionVoxel3D*>::iterator iterEnd = m_CollisionVoxel3DList.end();

		for (iter = m_CollisionVoxel3DList.begin(); iter != iterEnd; ++iter)
		{
			(*iter)->Remove(this);
		}
	}

#ifdef _DEBUG

	SAFE_RELEASE(m_pShader);
	SAFE_RELEASE(m_pMesh);
	SAFE_RELEASE(m_pSampler);

	for (int i = 0; i < RS_END; ++i)
	{
		SAFE_RELEASE(m_pRenderState[i]);
	}

#endif // _DEBUG
}

void CCollider::ToDynamicCollider()
{
}

void CCollider::ToStaticCollider()
{
}

void CCollider::ToKinematicCollider()
{
}

void CCollider::SetPhysicsMaterial(float fStaticFriction, float fDynamicFriction, float fRestitution)
{
	m_pPhysicsMaterial->setStaticFriction(fStaticFriction);
	m_pPhysicsMaterial->setDynamicFriction(fDynamicFriction);
	m_pPhysicsMaterial->setRestitution(fRestitution);
}

PxMaterial * CCollider::GetPhysicsMaterial() const
{
	return m_pPhysicsMaterial;
}

void CCollider::SetStaticFriction(float fStaticFriction)
{
	m_pPhysicsMaterial->setStaticFriction(fStaticFriction);
}

void CCollider::SetDynamicFriction(float fDynamicFriction)
{
	m_pPhysicsMaterial->setDynamicFriction(fDynamicFriction);
}

void CCollider::SetRestitution(float fRestitution)
{
	m_pPhysicsMaterial->setRestitution(fRestitution);
}

float CCollider::GetStaticFriction() const
{
	return static_cast<float>(m_pPhysicsMaterial->getStaticFriction());
}

float CCollider::GetDynamicFriction() const
{
	return static_cast<float>(m_pPhysicsMaterial->getDynamicFriction());
}

float CCollider::GetRestitution() const
{
	return static_cast<float>(m_pPhysicsMaterial->getRestitution());
}

#ifdef _DEBUG

void CCollider::SetRenderState(const string & strKey)
{	
	CRenderState*	pRenderState = GET_SINGLE(CRenderManager)->FindRenderState(strKey);

	if (!pRenderState)
		return;

	SAFE_RELEASE(m_pRenderState[pRenderState->GetRenderStateType()]);

	m_pRenderState[pRenderState->GetRenderStateType()] = pRenderState;
}

void CCollider::SetSampler()
{
	m_pSampler = GET_SINGLE(CResourcesManager)->FindSampler(SAMPLER_LINEAR);
}


#endif // _DEBUG

void CCollider::SetDebugColor(const Vector4 & vColor)
{
#ifdef _DEBUG
	m_vColliderColor = vColor;
#endif // _DEBUG
}
COLLIDER_TYPE CCollider::GetColliderType() const
{
	return m_eColliderType;
}

Vector3 CCollider::GetCenter() const
{
	return m_pTransform->GetWorldPosition() + m_vLocalPosition;
}

Vector3 CCollider::GetLocalPosition() const
{
	return m_vLocalPosition;
}

void CCollider::Straighten()
{
	float fDeltaTime = GET_SINGLE(CTimerManager)->FindTimer("MainTimer")->GetDeltaTime();
	
	unordered_map<CCollider*, CCollider*>::iterator iter;
	unordered_map<CCollider*, CCollider*>::iterator iterEnd = m_mapCollision.end();
	for (iter = m_mapCollision.begin(); iter != iterEnd; )
	{
		if (!CollisionCheck((iter)->second))
		{			
			CGameObject* pTargetObject = iter->second->GetGameObject();
			pTargetObject->OnCollisionExit(iter->second, this, fDeltaTime);
			SAFE_RELEASE(pTargetObject);

			m_pGameObject->OnCollisionExit(this, iter->second, fDeltaTime);
			iter->second->RemoveTargetFromCollisionList(this);
			iter = m_mapCollision.erase(iter);
		}
		else
		{
			++iter;
		}
	}
}

void CCollider::SetLocalPosition(const Vector3 & vLocalPosition)
{
	m_vLocalPosition = vLocalPosition;
}

void CCollider::SetLocalPosition(float x, float y, float z)
{
	m_vLocalPosition.x = x;
	m_vLocalPosition.y = y;
	m_vLocalPosition.z = z;
}

bool CCollider::Initialize()
{
	m_pGameObject->m_ColliderList.push_back(this);
	m_pScene->AddCollider(this);		
	return true;
}

int CCollider::Update(float fTime)
{
	return 0;
}

int CCollider::LateUpdate(float fTime)
{
	return 0;
}

int CCollider::OnCollisionEnter(CCollider* pThis, CCollider * pTarget, float fTime)
{
	return 0;
}

int CCollider::OnCollisionStay(CCollider* pThis, CCollider * pTarget, float fTime)
{
	return 0;
}

int CCollider::OnCollisionExit(CCollider* pThis, CCollider * pTarget, float fTime)
{
	return 0;
}

void CCollider::RenderDebug(float fTime)
{
#ifdef _DEBUG
	DEVICE_CONTEXT->IASetInputLayout(m_pLayout);

	m_pShader->SetShader();
	if (m_pSampler)
	{
		//Diffuse Sampler Register Numger = 0;
		m_pSampler->SetSampler(0);
	}

	if (m_pMesh)
	{
		m_pMesh->Render();
	}

#endif // _DEBUG
}



void CCollider::ClearCollisionVoxel()
{
	m_CollisionVoxel2DList.clear();
	m_CollisionVoxel3DList.clear();
}

size_t CCollider::GetCollisionCount() const
{
	return m_mapCollision.size();
}

void CCollider::AddCollisionList(CCollider * pTarget)
{
	unordered_map<CCollider*, CCollider*>::iterator iter = m_mapCollision.find(pTarget);

	if (iter == m_mapCollision.end())
	{
		m_mapCollision.insert(make_pair(pTarget, pTarget));
	}
}

void CCollider::RemoveTargetFromCollisionList(CCollider * pTarget)
{
	unordered_map<CCollider*, CCollider*>::iterator iter = m_mapCollision.find(pTarget);

	if (iter != m_mapCollision.end())
	{
		m_mapCollision.erase(iter);
	}
}

void CCollider::ClearCollisionList()
{
	m_mapCollision.clear();
}

bool CCollider::ContainCollision(CCollider * pTarget) const
{
	unordered_map<CCollider*, CCollider*>::const_iterator iter = m_mapCollision.find(pTarget);

	if (iter == m_mapCollision.end())
	{
		return false;
	}

	return true;
}


void CCollider::AddCollisionVoxel(CCollisionVoxel2D * pVoxel)
{
}

void CCollider::AddCollisionVoxel(CCollisionVoxel3D * pVoxel)
{
}

void CCollider::AddCollisionVoxel(const Vector2 & vVoxelKey)
{
}

void CCollider::AddCollisionVoxel(const Vector3 & vVoxelKey)
{
}

void CCollider::CalculateCollision2D(float fTime)
{
}

void CCollider::CalculateCollision3D(float fTime)
{
}

bool CCollider::CollisionCheck(CCollider* pTarget) const
{
	COLLIDER_TYPE eTargetColliderType = pTarget->GetColliderType();

	switch (m_eColliderType)
	{
	case SSS::CT_SPHERE:
	{
		switch (eTargetColliderType)
		{
		case SSS::CT_SPHERE:
		{
			return ((CSphereCollider*)this)->CollisionCheckWithSphereCollider(pTarget);
		}break;
		case SSS::CT_BOX:
		{
			return ((CSphereCollider*)this)->CollisionCheckWithBoxCollider(pTarget);
		}break;
		}
	}break;
	case SSS::CT_BOX:
	{
		switch (eTargetColliderType)
		{
		case SSS::CT_SPHERE:
		{
			return ((CBoxCollider*)this)->CollisionCheckWithSphereCollider(pTarget);
		}
			break;
		case SSS::CT_BOX:
		{
			return ((CBoxCollider*)this)->CollisionCheckWithBoxCollider(pTarget);
		}
			break;
		case SSS::CT_MESH:
			break;
		case SSS::CT_TERRAIN:
			break;
		default:
			break;
		}
	}break;


	case SSS::CT_RECT:
	{
		switch (eTargetColliderType)
		{
		case SSS::CT_RECT:
		{
			return ((CRectCollider2D*)this)->CollisionCheckWithRectCollider(pTarget, true);
		}
			break;
		case SSS::CT_CIRCLE:
		{
			return ((CRectCollider2D*)this)->CollisionCheckWithCircleCollider(pTarget);
		}
			break;
		default:
			break;
		}
	}
		break;
	case SSS::CT_CIRCLE:
	{
		switch (eTargetColliderType)
		{
		case SSS::CT_RECT:
		{
			return ((CCircleCollider2D*)this)->CollisionCheckWithRectCollider(pTarget);
		}
		break;
		case SSS::CT_CIRCLE:
		{
			return ((CCircleCollider2D*)this)->CollisionCheckWithCircleCollider(pTarget);
		}
		break;
		default:
			break;
		}
	}
		break;
	default:
		break;
	}
}

CCollider* CCollider::GetColliderInBegin() const
{
	return m_mapCollision.begin()->second;
}
