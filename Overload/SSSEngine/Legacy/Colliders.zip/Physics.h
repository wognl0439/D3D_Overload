#include "Engine.h"

SSS_BEGIN

#define XMVectorPermute( a, b, c) XMVectorPermute(a,b, c.i[0], c.i[1], c.i[2], c.i[3] )

struct _tagIntersectedVoxel
{
	float fDistanceFromOrigin;
	class CCollisionVoxel3D* pTarget;
};

struct _tagIntersectedCollider
{
	float fDistanceFromOrigin;
	class CCollider* pTarget;
};

class CPhysics
{
	DECLARE_SINGLE(CPhysics)
private:


public:
	class CCollider* RayCast(const Vector3& vOrigin, const Vector3& vDirection, const Vector4& vColor, Vector3* __out pIntersectPosition);
	class CCollider* RayCast(RAY tRay, Vector3* __out pIntersectPosition);

private:
	//Internal Collision Check
	bool IntersectRay(const Vector3& vRayOrigin, const Vector3& vRayDirection, class CCollider* pTargetCollider, Vector3* __out pPosition);
	static bool SortVoxelFromDistance(_tagIntersectedVoxel tVoxelA, _tagIntersectedVoxel tVoxelB);
	static bool SortColliderFromDistance(_tagIntersectedCollider pColliderA, _tagIntersectedCollider pColliderB);
	//Call Event Function


//XNA Math Functions
public:
	static bool XMVector3AnyTrue(const XMVECTOR& v);


public:		
	static bool IntersectRayDisk(const Vector3& Origin, const Vector3& Direction, const Vector3& vDiskCenter, const Vector3& vDiskRotation, float fDiskRadius, Vector3* __out pPosition = NULL);
	static bool IntersectRayPlane(const Vector3& Origin, const Vector3& Direction, const Vector3& vPlaneCenter, const Vector2& vPlaneVolume, const Vector3& vPlaneRotation, Vector3* __out pPosition = NULL);
	static bool IntersectRayTriangle(const Vector3& Origin, const Vector3& Direction, const Vector3& V0, const Vector3& V1, const Vector3& V2, Vector3* __out pPosition = NULL);
	static bool IntersectRaySphere(const Vector3& Origin, const Vector3& Direction, const Vector3& vSphereCenter, float fRadius, Vector3* __out pPosition = NULL);
	static bool IntersectRayAxisAlignedBox(const Vector3& Origin, const Vector3& Direction, const Vector3& vCenter, const Vector3& vVolume, Vector3*  __out pPosition = NULL);
	static bool IntersectRayOrientedBox(const Vector3& Origin, const Vector3& Direction, const Vector3& vCenter, const Vector3& vVolume, const Vector3& vRotation, Vector3* __out pPosition = NULL);
	static bool IntersectSphereSphere(const Vector3& vCenterA, float fRadiusA, const Vector3& vCenterB, float fRadiusB);
	static bool IntersectSphereAxisAlignedBox(const Vector3& vCenterA, float fRadiusA, const Vector3& vCenter, const Vector3& vVolume);
	static bool IntersectSphereOrientedBox(const Vector3& vSphereCenter, float fRadius, const Vector3& vCenter, const Vector3& vVolume, const Vector3& vRotation);
	static bool IntersectAxisAlignedBoxAxisAlignedBox(const Vector3& vCenterA, const Vector3& vVolumeA, const Vector3& vCenterB, const Vector3& vVolumeB);
	static bool IntersectAxisAlignedBoxOrientedBox(const Vector3& vCenterA, const Vector3& vVolumeA, const Vector3& vCenterB, const Vector3& vVolumeB,const Vector3& vRotationB );
	static bool IntersectOrientedBoxOrientedBox(const Vector3& vCenterA, const Vector3& vVolumeA, const Vector3& vRotationA, const Vector3& vCenterB, const Vector3& vVolumeB, const Vector3& vRotationB);

	//-----------------------------------------------------------------------------
	//	����ü �浹 ���� ��
	//		0 = �浹 ����, 
	//		1 = �ɲ��̶� ����, 
	//		2 = ������ ����ü �ȿ� �� ����
	//-----------------------------------------------------------------------------
	static int IntersectFrustumSphere(const Vector3 & vCenter, float fRadius, const Vector3& vFrustumOrigin, const Vector3& vFrustumRotation, float fHorizontalLength, float fVerticalLength, float fNearPlane, float fFarPlane);
	static int IntersectFrustumAxisAlignedBox(const Vector3 & vCenter, const Vector3& vVolume, const Vector3& vFrustumOrigin, const Vector3& vFrustumRotation, float fHorizontalLength, float fVerticalLength, float fNearPlane, float fFarPlane);
	static int IntersectFrustumOrientedBox(const Vector3 & vCenter, const Vector3& vVolume, const Vector3& vRotation,const Vector3& vFrustumOrigin, const Vector3& vFrustumRotation, float fHorizontalLength, float fVerticalLength, float fNearPlane, float fFarPlane);

private:
	static XMVECTOR PointOnLineSegmentNearestPoint(FXMVECTOR S1, FXMVECTOR S2, FXMVECTOR P);
	



public:
	bool Initialize();

};

SSS_END
