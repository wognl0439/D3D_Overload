
#include "Engine.h"



//PhysX
#ifdef _WIN64
#ifdef _DEBUG
#pragma comment(lib, "LowLevelDEBUG_x64")
#pragma comment(lib, "LowLevelAABBDEBUG_x64")
#pragma comment(lib, "LowLevelClothDEBUG_x64")
#pragma comment(lib, "LowLevelDynamicsDEBUG_x64")
#pragma comment(lib, "LowLevelParticlesDEBUG_x64")
#pragma comment(lib, "PhysX3DEBUG_x64")
#pragma comment(lib, "PhysX3CharacterKinematicDEBUG_x64")
#pragma comment(lib, "PhysX3CommonDEBUG_x64")
#pragma comment(lib, "PhysX3CookingDEBUG_x64")
#pragma comment(lib, "PhysX3ExtensionsDEBUG_x64")
#pragma comment(lib, "PhysX3VehicleDEBUG_x64")
#pragma comment(lib, "SceneQueryDEBUG_x64")
#pragma comment(lib, "PsFastXmlDEBUG_x64")
#pragma comment(lib, "PxFoundationDEBUG_x64")
#pragma comment(lib, "PxPvdSDKDEBUG_x64")
#pragma comment(lib, "PxTaskDEBUG_x64")
#pragma comment(lib, "SimulationControllerDEBUG_x64")
#else
#pragma comment(lib, "LowLevel_x64")
#pragma comment(lib, "LowLevelAABB_x64")
#pragma comment(lib, "LowLevelCloth_x64")
#pragma comment(lib, "LowLevelDynamics_x64")
#pragma comment(lib, "LowLevelParticles_x64")
#pragma comment(lib, "PhysX3_x64")
#pragma comment(lib, "PhysX3CharacterKinematic_x64")
#pragma comment(lib, "PhysX3Common_x64")
#pragma comment(lib, "PhysX3Cooking_x64")
#pragma comment(lib, "PhysX3Extensions_x64")
#pragma comment(lib, "PhysX3Vehicle_x64")
#pragma comment(lib, "SceneQuery_x64")
#pragma comment(lib, "PsFastXml_x64")
#pragma comment(lib, "PxFoundation_x64")
#pragma comment(lib, "PxPvdSDK_x64")
#pragma comment(lib, "PxTask_x64")
#pragma comment(lib, "SimulationController_x64")
#endif // _DEBUG
#else
#ifdef _DEBUG
#pragma comment(lib, "LowLevelDEBUG_x86")
#pragma comment(lib, "LowLevelAABBDEBUG_x86")
#pragma comment(lib, "LowLevelClothDEBUG_x86")
#pragma comment(lib, "LowLevelDynamicsDEBUG_x86")
#pragma comment(lib, "LowLevelParticlesDEBUG_x86")
#pragma comment(lib, "PhysX3DEBUG_x86")
#pragma comment(lib, "PhysX3CharacterKinematicDEBUG_x86")
#pragma comment(lib, "PhysX3CommonDEBUG_x86")
#pragma comment(lib, "PhysX3CookingDEBUG_x86")
#pragma comment(lib, "PhysX3ExtensionsDEBUG_x86")
#pragma comment(lib, "PhysX3VehicleDEBUG_x86")
#pragma comment(lib, "SceneQueryDEBUG_x86")
#pragma comment(lib, "PsFastXmlDEBUG_x86")
#pragma comment(lib, "PxFoundationDEBUG_x86")
#pragma comment(lib, "PxPvdSDKDEBUG_x86")
#pragma comment(lib, "PxTaskDEBUG_x86")
#pragma comment(lib, "SimulationControllerDEBUG_x86")
#else
#pragma comment(lib, "LowLevel_x86")
#pragma comment(lib, "LowLevelAABB_x86")
#pragma comment(lib, "LowLevelCloth_x86")
#pragma comment(lib, "LowLevelDynamics_x86")
#pragma comment(lib, "LowLevelParticles_x86")
#pragma comment(lib, "PhysX3_x86")
#pragma comment(lib, "PhysX3CharacterKinematic_x86")
#pragma comment(lib, "PhysX3Common_x86")
#pragma comment(lib, "PhysX3Cooking_x86")
#pragma comment(lib, "PhysX3Extensions_x86")
#pragma comment(lib, "PhysX3Vehicle_x86")
#pragma comment(lib, "SceneQuery_x86")
#pragma comment(lib, "PsFastXml_x86")
#pragma comment(lib, "PxFoundation_x86")
#pragma comment(lib, "PxPvdSDK_x86")
#pragma comment(lib, "PxTask_x86")
#pragma comment(lib, "SimulationController_x86")
#endif // _DEBUG
#endif



#include "PxPhysicsAPI.h"
//����
#include "extensions/PxRepXSimpleType.h"
#include "extensions/PxSceneQueryExt.h"
#include "extensions/PxRigidActorExt.h"
#include "extensions/PxRaycastCCD.h"
#include "extensions/PxMassProperties.h"
#include "extensions/PxDefaultSimulationFilterShader.h"
#include "extensions/PxDefaultErrorCallback.h"
#include "extensions/PxDefaultCpuDispatcher.h"
#include "extensions/PxDefaultAllocator.h"
#include "extensions/PxD6Joint.h"
#include "extensions/PxConstraintExt.h"
#include "extensions/PxCollectionExt.h"
#include "extensions/PxClothTetherCooker.h"
#include "extensions/PxClothMeshQuadifier.h"
#include "extensions/PxClothMeshDesc.h"
#include "extensions/PxClothFabricCooker.h"
#include "extensions/PxBroadPhaseExt.h"
#include "extensions/PxBinaryConverter.h"

using namespace physx;

SSS_BEGIN

class SSS_DLL CCollisionManager
{
	DECLARE_SINGLE(CCollisionManager)
	

public:
	PxDefaultAllocator			m_Allocator;
	PxDefaultErrorCallback		m_ErrorCallback;
	PxFoundation*				m_pFoundation;
	PxPhysics*						m_pPhysics;
	PxDefaultCpuDispatcher*	m_pDispatcher;
	PxScene*						m_pScene;
	PxMaterial*						m_pMaterial;
	PxPvd*							m_pPvd;

private:
	float m_fFixedTimeStep;
	float m_fCullingDistance;
	Vector3 m_vGravity;


public:
	PxPhysics* GetPhysics() const;
	void AddCollider(class CCollider* pCollider = NULL);
	void SetGravity(const Vector3& vGravity);
	Vector3 GetGravity() const;

	float GetCullingDistance() const;
	void SetCullingDistance(float fDistance);
	float GetFixedTimeStep() const;
	void SetFixedTimeStep(float fTimeStep);
	void Reset();



private:
	unordered_map<Vector2, class CCollisionVoxel2D*> m_mapCollisionVoxel2D;
	unordered_map<Vector3, class CCollisionVoxel3D*> m_mapCollisionVoxel3D;
	Vector2 m_vVoxelSize2D;
	Vector3 m_vVoxelSize3D;
	class CUICollider* m_pCoveredButtonCollider;
	class CCollider* m_pCoveredCollider;

private:
	PxRigidDynamic* CreateDynamic(const PxTransform& t, const PxGeometry& geometry, const PxVec3& velocity = PxVec3(0));
	void CreateStack(const PxTransform& t, PxU32 size, PxReal halfExtent);
	void CleanupPhysics(bool interactive);

public:
	void ClearCoveredUI();
	void ClearCoveredCollider();
	class CUICollider* GetCoveredUI() const;
	class CCollider* GetCoveredCollider() const;
	size_t GetVoxel2DCount() const;
	size_t GetVoxel3DCount() const;
	Vector2 GetVoxelSize2D() const;
	Vector3 GetVoxelSize3D() const; 
	const unordered_map<Vector2, class CCollisionVoxel2D*>& GetVoxel2D() const;
	const unordered_map<Vector3, class CCollisionVoxel3D*>& GetVoxel3D() const;
	class CCollisionVoxel2D* GetVoxel2D(const Vector2& position) ;
	class CCollisionVoxel2D* GetVoxel2D(const Vector3& position) ;
	class CCollisionVoxel2D* GetVoxel2D(float x, float y) ;
	class CCollisionVoxel3D* GetVoxel3D(const Vector3& position);
	class CCollisionVoxel3D* GetVoxel3D(float x, float y, float z) ;
	

public:
	void SetVoxelSize2D(const Vector2& vSize);
	void SetVoxelSize2D(float fWidth, float fHeight);
	void SetVoxelSize3D(const Vector3& vSize);
	void SetVoxelSize3D(float x, float y, float z);

public:

	void RemoveVoxel2D(const Vector2& vKeyPosition);
	void RemoveVoxel2D(float fKeyX, float fKeyY);
	void RemoveVoxel2D(class CCollisionVoxel2D* pTarget);
	void RemoveVoxel3D(const Vector3& vKeyPosition);
	void RemoveVoxel3D(float fKeyX, float fKeyY, float fKeyZ);
	class CCollisionVoxel2D* CreateEmptyVoxel(const Vector2& vKeyPosition);
	class CCollisionVoxel3D* CreateEmptyVoxel(const Vector3& vKeyPosition);
	class CCollisionVoxel2D* CreateVoxel(const Vector2& vKeyPosition);
	class CCollisionVoxel3D* CreateVoxel(const Vector3& vKeyPosition);

	void ClearVoxel2D();
	void ClearVoxel3D();
	



public:
	bool Initialize();
	int UpdateCollision(float fTime);

};


SSS_END