#pragma once
#include "../Collider.h"

SSS_BEGIN

class SSS_DLL CSphereCollider :
	public CCollider
{
private:
	friend class CGameObject;
private:
	CSphereCollider();
	CSphereCollider(const CSphereCollider& component);
	~CSphereCollider();


private:	
	float m_fRadius;


public:
	float GetRadius() const;
	void SetRadius(float fRadius);
	void SetCollisionVoxel() override;

public:
	bool CollisionCheckWithBoxCollider(CCollider* pTarget);
	bool CollisionCheckWithSphereCollider(CCollider* pTarget);
	
public:
	int LateUpdate(float fTime) override;
	void RenderDebug(float fDeltaTime) override;
	int OnCollisionEnter(class CCollider* pThis, class CCollider* pTarget, float fTime)override;
	int OnCollisionStay(class CCollider* pThis, class CCollider* pTarget, float fTime)override;
	int OnCollisionExit(class CCollider* pThis, class CCollider* pTarget, float fTime)override;

	void OnMouseEnter(class CCollider* pTarget, const Vector2& vPosition, const Vector3& vIntersectPosition) override;
	void OnMouseExit(class CCollider* pTarget, const Vector2& vPosition, const Vector3& vIntersectPosition) override;
	CSphereCollider* Clone() const override;
	
	bool Save(FILE* pFile) override;
	bool Load(FILE* pFile) override;
};
SSS_END