#pragma once
#include "../Collider.h"

SSS_BEGIN

//�⺻���� OBB �浹�� �����ϵ��� ��
class SSS_DLL CBoxCollider :
	public CCollider
{
private:
	friend class CGameObject;
	
public:
	CBoxCollider();
	~CBoxCollider();
		
private:
	Vector3 m_vVolume;

public:
	void SetVolume(const Vector3& vScale);
	Vector3 GetVolume() const;
	void SetCollisionVoxel() override;

public:
	bool CollisionCheckWithBoxCollider(CCollider* pTarget);
	bool CollisionCheckWithSphereCollider(CCollider* pTarget);

public:
	int LateUpdate(float fTime) override;
	void RenderDebug(float fDeltaTime) override;

	int OnCollisionEnter(class CCollider* pThis, class CCollider* pTarget, float fTime)override;
	int OnCollisionStay(class CCollider* pThis, class CCollider* pTarget, float fTime)override;
	int OnCollisionExit(class CCollider* pThis, class CCollider* pTarget, float fTime)override;

	void OnMouseEnter(class CCollider* pTarget, const Vector2& vPosition, const Vector3& vIntersectPosition) override;
	void OnMouseExit(class CCollider* pTarget, const Vector2& vPosition, const Vector3& vIntersectPosition) override;
	CBoxCollider* Clone() const override;

	bool Save(FILE* pFile) override;
	bool Load(FILE* pFile) override;
};

SSS_END