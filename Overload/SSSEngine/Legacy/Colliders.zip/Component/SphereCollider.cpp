#include "SphereCollider.h"
#include "../ResourcesManager.h"
#include "../ShaderManager.h"
#include "../CollisionVoxel3D.h"
#include "../Transform.h"
#include "../Physics.h"
#include "BoxCollider.h"
#include "Rigidbody.h"
#include "../CollisionManager.h"

#ifdef  _DEBUG
#include "Camera.h"
#include "../RenderManager.h"
#include "../RenderState.h"
#include "../Scene.h"
#include "../Layer.h"
#include "../Mesh.h"
#include "../Sampler.h"
#endif //  _DEBUG

using namespace physx;

SSS_USING

CSphereCollider::CSphereCollider()
{
	m_fRadius = 1.0f;
	m_eColliderType = CT_SPHERE;
	SetTag("Sphere Collider");


	//Rigidbody�� ������ 
	Vector3 vPosition = m_pTransform->GetWorldPosition();
	Vector4 vQuaternion = m_pTransform->GetWorldRotation().ToQuaternion();
	PxTransform cTransform(vPosition.x, vPosition.y, vPosition.z, PxQuat(vQuaternion.x, vQuaternion.y, vQuaternion.z, vQuaternion.w));


	bool bIsStatic = m_pGameObject->IsStatic();
	bool bIsKinematic = true;
	CRigidbody* pRigidbody = GetComponent<CRigidbody>();
	if (pRigidbody)
	{
		bIsKinematic = pRigidbody->IsKinematic();
	}
	PxMaterial* 
	m_pShape = GET_SINGLE(CCollisionManager)->GetPhysics()->createShape(PxSphereGeometry(1.0f), NULL,)

	if (bIsKinematic)
	{
		if (bIsStatic)
		{
			//Static
			m_pActor = GET_SINGLE(CCollisionManager)->GetPhysics()->createRigidStatic(cTransform);
			((PxRigidStatic*)m_pActor)->setName(m_pGameObject->GetTag().c_str());
			((PxRigidStatic*)m_pActor)->attachShape();
		}
		else
		{
			//Dynamic Collider Using Kinematic
			m_pActor = GET_SINGLE(CCollisionManager)->GetPhysics()->createRigidDynamic(cTransform);
			((PxRigidDynamic*)m_pActor)->setRigidBodyFlag(PxRigidBodyFlag::eKINEMATIC, true); 
			((PxRigidDynamic*)m_pActor)->setName(m_pGameObject->GetTag().c_str());
		}
	}
	else
	{
		//Dynamic Collider No Using Kinematic
		m_pActor = GET_SINGLE(CCollisionManager)->GetPhysics()->createRigidDynamic(cTransform);
		((PxRigidDynamic*)m_pActor)->setRigidBodyFlag(PxRigidBodyFlag::eKINEMATIC, false);
		((PxRigidDynamic*)m_pActor)->setName(m_pGameObject->GetTag().c_str());
	}


#ifdef _DEBUG
	m_pShader = GET_SINGLE(CShaderManager)->FindShader(COLLIDER_SHADER);
	m_pMesh = GET_SINGLE(CResourcesManager)->FindMesh(PRIMITIVE_MESH_SPHERE);
	m_pLayout = GET_SINGLE(CShaderManager)->FindInputLayout(POS_COLOR_LAYOUT);
		
	SetRenderState(WIREFRAME);
#endif // _DEBUG
}

CSphereCollider::CSphereCollider(const CSphereCollider & component):
	CCollider(component)
{
	*this = component;
}

CSphereCollider::~CSphereCollider()
{
}

float CSphereCollider::GetRadius() const
{
	return m_fRadius;
}

void CSphereCollider::SetRadius(float fRadius)
{
	m_fRadius = fRadius;
}

void CSphereCollider::SetCollisionVoxel()
{
	Vector3 vCenterPosition = GetCenter();
	Vector3 vScale = Vector3::One * m_fRadius * 2.0f;
	Vector3 vMin = vCenterPosition - m_fRadius;
	Vector3 vMax = vMin + vScale;
	Vector3 vVoxelSize = GET_SINGLE(CCollisionManager)->GetVoxelSize3D();

	list<CCollisionVoxel3D*>::iterator iter;
	list<CCollisionVoxel3D*>::iterator iterEnd = m_CollisionVoxel3DList.end();
	for (iter = m_CollisionVoxel3DList.begin(); iter != iterEnd; ++iter)
	{
		if ((*iter)->Contain((CCollider*)this))
		{
			(*iter)->Remove((CCollider*)this);
		}
	}

	m_CollisionVoxel3DList.clear();
	
	Vector3 VoxelMin = Vector3((int)vMin.x / (int)vVoxelSize.x, (int)vMin.y / (int)vVoxelSize.y, (int)vMin.z / (int)vVoxelSize.z);
	Vector3 VoxelMax = Vector3((int)vMax.x / (int)vVoxelSize.x, (int)vMax.y / (int)vVoxelSize.y, (int)vMax.z / (int)vVoxelSize.z);
	Vector3::SetMinMaxVolume(&VoxelMin, &VoxelMax);

	if (VoxelMin == VoxelMax)
	{
		CCollisionVoxel3D* pVoxel = GET_SINGLE(CCollisionManager)->GetVoxel3D(Vector3(VoxelMin.x, VoxelMin.y, VoxelMin.z));

		if (pVoxel)
		{
			pVoxel->AddGameObject((CCollider*)this);
			m_CollisionVoxel3DList.push_back(pVoxel);
		}
		else
		{
			pVoxel = GET_SINGLE(CCollisionManager)->CreateEmptyVoxel(Vector3(VoxelMin.x, VoxelMin.y, VoxelMin.z));
			pVoxel->AddGameObject(m_pGameObject);
			m_CollisionVoxel3DList.push_back(pVoxel);
		}
	}
	else
	{
		//�ߺ� �� ��� �ڵ����� �ɷ�����.
		for (int z = VoxelMin.z; z <= VoxelMax.z; ++z)
		{
			for (int y = VoxelMin.y; y <= VoxelMax.y; ++y)
			{
				for (int x = VoxelMin.x; x <= VoxelMax.x; ++x)
				{
					CCollisionVoxel3D* pVoxel = GET_SINGLE(CCollisionManager)->GetVoxel3D(Vector3(x, y, z));					
					if (pVoxel)
					{
						pVoxel->AddGameObject(m_pGameObject);
						m_CollisionVoxel3DList.push_back(pVoxel);
					}
					else
					{
						pVoxel = GET_SINGLE(CCollisionManager)->CreateEmptyVoxel(Vector3(x, y, z));
						pVoxel->AddGameObject(m_pGameObject);
					}
				}
			}
		}
	}
}

bool CSphereCollider::CollisionCheckWithBoxCollider(CCollider * pTarget)
{
	CBoxCollider* pTargetCollider = (CBoxCollider*)pTarget;

	CTransform* pTargetTransform = pTarget->GetTransform();
	Vector3 vTargetCenter = pTargetCollider->GetCenter();
	Vector3 vTargetRotation = pTargetTransform->GetWorldRotation();
	Vector3 vTargetVolume = pTargetCollider->GetVolume();
	SAFE_RELEASE(pTargetTransform);
	
	return CPhysics::IntersectSphereOrientedBox(GetCenter(), m_fRadius, vTargetCenter, vTargetVolume, vTargetRotation);
}

bool CSphereCollider::CollisionCheckWithSphereCollider(CCollider * pTarget)
{
	CSphereCollider* pTargetCollider = dynamic_cast<CSphereCollider*>(pTarget);
	Vector3 vCenter = GetCenter();
	Vector3 vTargetCenter = pTargetCollider->GetCenter();
	float fTargetRadius = pTargetCollider->GetRadius();

	return CPhysics::IntersectSphereSphere(vCenter, m_fRadius, vTargetCenter, fTargetRadius);
}

int CSphereCollider::LateUpdate(float fTime)
{
	return 0;
}

void CSphereCollider::RenderDebug(float fDeltaTime)
{
#ifdef _DEBUG
	TRANSFORMCBUFFER	tBuffer = {};

	//������
	//�޽��� ���ؽ��� ���̰� 1�̹Ƿ�, scale�� max�� �ȴ�.

	Matrix	matScale, matPos, matWorld;
	matScale = Matrix::Scaling(Vector3::One * m_fRadius * 2.0f);
	matPos = Matrix::Translation(GetCenter());
	matWorld = matScale * m_pTransform->GetWorldRotationMatrix() * matPos;

	CCamera*	pCamera = m_pScene->GetMainCamera();

	tBuffer.matWorld = matWorld;
	tBuffer.matView = pCamera->GetViewMatrix();
	tBuffer.matProjection = pCamera->GetPerspectiveProjectionMatrix();
	tBuffer.matWV = matWorld * tBuffer.matView;
	tBuffer.matWVP = tBuffer.matWV * tBuffer.matProjection;
	tBuffer.matVP = tBuffer.matView * tBuffer.matProjection;
	tBuffer.matWP = tBuffer.matWorld * tBuffer.matProjection;
	tBuffer.vPivot = Vector3::Zero;
	tBuffer.vLength = m_pMesh->GetLength();

	SAFE_RELEASE(pCamera);

	tBuffer.matWorld = tBuffer.matWorld.Transpose();
	tBuffer.matView = tBuffer.matView.Transpose();
	tBuffer.matProjection = tBuffer.matProjection.Transpose();
	tBuffer.matWV = tBuffer.matWV.Transpose();
	tBuffer.matWVP = tBuffer.matWVP.Transpose();
	tBuffer.matVP = tBuffer.matVP.Transpose();
	tBuffer.matWP = tBuffer.matWP.Transpose();

	// Transform ������ Shader ������۷� �Ѱ��ش�.
	GET_SINGLE(CShaderManager)->UpdateConstantBuffer(TRANSFORM_CBUFFER, 	&tBuffer, SSS::CBT_VERTEX | CBT_PIXEL | CBT_GEOMETRY);
	

	for (int i = 0; i < RS_END; ++i)
	{
		if (m_pRenderState[i])
			m_pRenderState[i]->SetState();
	}
	
	COLLIDERCBUFFER tColliderBuffer = {};
	tColliderBuffer.bUI = 0;
	tColliderBuffer.vColor = m_vColliderColor;
	GET_SINGLE(CShaderManager)->UpdateConstantBuffer(COLLIDER_CBUFFER, &tColliderBuffer, SSS::CBT_VERTEX);
	CCollider::RenderDebug(fDeltaTime);


	for (int i = 0; i < RS_END; ++i)
	{
		if (m_pRenderState[i])
			m_pRenderState[i]->ResetState();
	}
#endif // _DEBUG
}

int CSphereCollider::OnCollisionEnter(CCollider * pThis, CCollider * pTarget, float fTime)
{
#ifdef _DEBUG
	m_vColliderColor = Vector4::red;
#endif
	return 0;
}

int CSphereCollider::OnCollisionStay(CCollider * pThis, CCollider * pTarget, float fTime)
{
	return 0;
}

int CSphereCollider::OnCollisionExit(CCollider * pThis, CCollider * pTarget, float fTime)
{
#ifdef _DEBUG
	m_vColliderColor = Vector4::green;
#endif
	return 0;
}

void CSphereCollider::OnMouseEnter(CCollider* pTarget, const Vector2 & vPosition, const Vector3 & vIntersectPosition)
{
#ifdef _DEBUG
	m_vColliderColor = Vector4::red;
#endif
}

void CSphereCollider::OnMouseExit(CCollider* pTarget, const Vector2 & vPosition, const Vector3 & vIntersectPosition)
{
#ifdef _DEBUG
	m_vColliderColor = Vector4::green;
#endif
}

CSphereCollider * CSphereCollider::Clone() const
{
	return new CSphereCollider(*this);
}

bool CSphereCollider::Save(FILE * pFile)
{
	fwrite(&m_vLocalPosition, sizeof(Vector3), 1, pFile);
	fwrite(&m_fRadius, sizeof(float), 1, pFile);

	return true;
}

bool CSphereCollider::Load(FILE * pFile)
{
	fread(&m_vLocalPosition, sizeof(Vector3), 1, pFile);
	fread(&m_fRadius, sizeof(float), 1, pFile);

	return true;
}
