#include "BoxCollider.h"
#include "../Transform.h"
#include "../GameObject.h"
#include "../CollisionManager.h"
#include "../CollisionVoxel3D.h"
#include "../Physics.h"
#include "SphereCollider.h"
#include "../ShaderManager.h"
#include "../ResourcesManager.h"
#include "Camera.h"
#include "../Scene.h"
#include "../Mesh.h"
#include "../RenderState.h"

SSS_USING

CBoxCollider::CBoxCollider():
	m_vVolume(Vector3::One)
{
	m_eColliderType = CT_BOX;
	SetTag("Box Collider");

#ifdef _DEBUG
	m_pShader = GET_SINGLE(CShaderManager)->FindShader(COLLIDER_SHADER);
	m_pMesh = GET_SINGLE(CResourcesManager)->FindMesh(PRIMITIVE_MESH_CUBE);
	m_pLayout = GET_SINGLE(CShaderManager)->FindInputLayout(POS_COLOR_LAYOUT);

	SetRenderState(WIREFRAME);
#endif // _DEBUG
}
CBoxCollider::~CBoxCollider()
{
}

void CBoxCollider::SetVolume(const Vector3 & vVolume)
{
	m_vVolume = vVolume;
}

Vector3 CBoxCollider::GetVolume() const
{
	return m_vVolume;
}

void CBoxCollider::SetCollisionVoxel()
{
	Vector3 vCenterPosition = GetCenter();
	Vector3 vMin = vCenterPosition - m_vVolume * 0.5f;
	Vector3 vMax = vMin + m_vVolume;
	Vector3 vVoxelSize = GET_SINGLE(CCollisionManager)->GetVoxelSize3D();

	list<CCollisionVoxel3D*>::iterator iter;
	list<CCollisionVoxel3D*>::iterator iterEnd = m_CollisionVoxel3DList.end();
	for (iter = m_CollisionVoxel3DList.begin(); iter != iterEnd; ++iter)
	{
		if ((*iter)->Contain((CCollider*)this))
		{
			(*iter)->Remove((CCollider*)this);
		}
	}

	m_CollisionVoxel3DList.clear();

	Vector3 VoxelMin = Vector3((int)vMin.x / (int)vVoxelSize.x, (int)vMin.y / (int)vVoxelSize.y, (int)vMin.z / (int)vVoxelSize.z);
	Vector3 VoxelMax = Vector3((int)vMax.x / (int)vVoxelSize.x, (int)vMax.y / (int)vVoxelSize.y, (int)vMax.z / (int)vVoxelSize.z);
	Vector3::SetMinMaxVolume(&VoxelMin, &VoxelMax);

	if (VoxelMin == VoxelMax)
	{
		CCollisionVoxel3D* pVoxel = GET_SINGLE(CCollisionManager)->GetVoxel3D(Vector3(VoxelMin.x, VoxelMin.y, VoxelMin.z));

		if (pVoxel)
		{
			pVoxel->AddGameObject((CCollider*)this);
			m_CollisionVoxel3DList.push_back(pVoxel);
		}
		else
		{
			pVoxel = GET_SINGLE(CCollisionManager)->CreateEmptyVoxel(Vector3(VoxelMin.x, VoxelMin.y, VoxelMin.z));
			pVoxel->AddGameObject(m_pGameObject);
			m_CollisionVoxel3DList.push_back(pVoxel);
		}
	}
	else
	{
		//�ߺ� �� ��� �ڵ����� �ɷ�����.
		for (int z = VoxelMin.z; z <= VoxelMax.z; ++z)
		{
			for (int y = VoxelMin.y; y <= VoxelMax.y; ++y)
			{
				for (int x = VoxelMin.x; x <= VoxelMax.x; ++x)
				{
					CCollisionVoxel3D* pVoxel = GET_SINGLE(CCollisionManager)->GetVoxel3D(Vector3(x, y, z));
					if (pVoxel)
					{
						pVoxel->AddGameObject(m_pGameObject);
						m_CollisionVoxel3DList.push_back(pVoxel);
					}
					else
					{
						pVoxel = GET_SINGLE(CCollisionManager)->CreateEmptyVoxel(Vector3(x, y, z));
						pVoxel->AddGameObject(m_pGameObject);
						m_CollisionVoxel3DList.push_back(pVoxel);
					}
				}
			}
		}
	}
}

bool CBoxCollider::CollisionCheckWithBoxCollider(CCollider * pTarget)
{
	//�ݵ�� BoxCollider�� ������ ������ dynamic_cast ����
	//Down Casting�� �� �ʿ䰡 ����.
	CBoxCollider* pTargetCollider = (CBoxCollider*)pTarget;
	CTransform* pTargetTransform = pTarget->GetTransform();

	Vector3 vTargetCenter = pTargetCollider->GetCenter();
	Vector3 vTargetRotation = pTargetTransform->GetWorldRotation();
	Vector3 vTargetVolume = pTargetCollider->GetVolume() * pTargetTransform->GetWorldScale();
	SAFE_RELEASE(pTargetTransform);

	Vector3 vCenter = GetCenter();
	Vector3 vRotation = m_pTransform->GetWorldRotation();
	Vector3 vVolume = m_vVolume * m_pTransform->GetWorldScale();

	return CPhysics::IntersectOrientedBoxOrientedBox(vTargetCenter, vTargetVolume, vTargetRotation, vCenter, vVolume, vRotation);
}

bool CBoxCollider::CollisionCheckWithSphereCollider(CCollider * pTarget)
{
	CSphereCollider* pTargetCollider = (CSphereCollider*)pTarget;
	CTransform* pTargetTransform = pTarget->GetTransform();
	Vector3 pTargetCenter = pTargetCollider->GetCenter();
	float fTargetRadius = pTargetCollider->GetRadius();
	SAFE_RELEASE(pTargetTransform);

	Vector3 vCenter = GetCenter();
	Vector3 vRotation = m_pTransform->GetWorldRotation();
	Vector3 vVolume = m_vVolume;

	return CPhysics::IntersectSphereOrientedBox(pTargetCenter, fTargetRadius, vCenter, vVolume, vRotation);
}

int CBoxCollider::LateUpdate(float fTime)
{
	return 0;
}

void CBoxCollider::RenderDebug(float fDeltaTime)
{
#ifdef _DEBUG
	TRANSFORMCBUFFER	tBuffer = {};

	Vector3 vCenter = GetCenter();

	//������
	Matrix	matScale, matPos, matWorld;
	matScale = Matrix::Scaling(m_vVolume * m_pTransform->GetWorldScale());
	matPos = Matrix::Translation(vCenter);
	matWorld = matScale * m_pTransform->GetWorldRotationMatrix() * matPos ;

	CCamera*	pCamera = m_pScene->GetMainCamera();

	tBuffer.matWorld = matWorld;
	tBuffer.matView = pCamera->GetViewMatrix();
	tBuffer.matProjection = pCamera->GetPerspectiveProjectionMatrix();
	tBuffer.matWV = matWorld * tBuffer.matView;
	tBuffer.matWVP = tBuffer.matWV * tBuffer.matProjection;
	tBuffer.matVP = tBuffer.matView * tBuffer.matProjection;
	tBuffer.matWP = tBuffer.matWorld * tBuffer.matProjection;
	tBuffer.vPivot = Vector3::Zero;
	tBuffer.vLength = m_pMesh->GetLength();

	SAFE_RELEASE(pCamera);

	tBuffer.matWorld = tBuffer.matWorld.Transpose();
	tBuffer.matView = tBuffer.matView.Transpose();
	tBuffer.matProjection = tBuffer.matProjection.Transpose();
	tBuffer.matWV = tBuffer.matWV.Transpose();
	tBuffer.matWVP = tBuffer.matWVP.Transpose();
	tBuffer.matVP = tBuffer.matVP.Transpose();
	tBuffer.matWP = tBuffer.matWP.Transpose();

	// Transform ������ Shader ������۷� �Ѱ��ش�.
	GET_SINGLE(CShaderManager)->UpdateConstantBuffer(TRANSFORM_CBUFFER, &tBuffer, SSS::CBT_VERTEX | CBT_PIXEL | CBT_GEOMETRY);


	for (int i = 0; i < RS_END; ++i)
	{
		if (m_pRenderState[i])
			m_pRenderState[i]->SetState();
	}

	COLLIDERCBUFFER tColliderBuffer = {};
	tColliderBuffer.bUI = 0;
	tColliderBuffer.vColor = m_vColliderColor;
	GET_SINGLE(CShaderManager)->UpdateConstantBuffer(COLLIDER_CBUFFER, &tColliderBuffer, SSS::CBT_VERTEX);
	CCollider::RenderDebug(fDeltaTime);


	for (int i = 0; i < RS_END; ++i)
	{
		if (m_pRenderState[i])
			m_pRenderState[i]->ResetState();
	}
#endif // _DEBUG
}

int CBoxCollider::OnCollisionEnter(CCollider * pThis, CCollider * pTarget, float fTime)
{
#ifdef _DEBUG
	m_vColliderColor = Vector4::red;
#endif
	return 0;
}

int CBoxCollider::OnCollisionStay(CCollider * pThis, CCollider * pTarget, float fTime)
{
	return 0;
}

int CBoxCollider::OnCollisionExit(CCollider * pThis, CCollider * pTarget, float fTime)
{
#ifdef _DEBUG
	m_vColliderColor = Vector4::green;
#endif
	return 0;
}

void CBoxCollider::OnMouseEnter(CCollider* pTarget, const Vector2 & vPosition, const Vector3 & vIntersectPosition)
{
#ifdef _DEBUG
	m_vColliderColor = Vector4::red;
#endif
}

void CBoxCollider::OnMouseExit(CCollider* pTarget, const Vector2 & vPosition, const Vector3 & vIntersectPosition)
{
#ifdef _DEBUG
	m_vColliderColor = Vector4::green;
#endif
}

CBoxCollider * CBoxCollider::Clone() const
{
	return new CBoxCollider(*this);
}

bool CBoxCollider::Save(FILE * pFile)
{
	fwrite(&m_vLocalPosition, sizeof(Vector3), 1, pFile);
	fwrite(&m_vVolume, sizeof(Vector3), 1, pFile);

	return true;
}

bool CBoxCollider::Load(FILE * pFile)
{
	fread(&m_vLocalPosition, sizeof(Vector3), 1, pFile);
	fread(&m_vVolume, sizeof(Vector3), 1, pFile);

	return true;
}
