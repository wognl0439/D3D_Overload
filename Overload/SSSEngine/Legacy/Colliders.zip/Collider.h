#pragma once
#include "Component.h"
#include "PxPhysicsAPI.h"
using namespace physx;

SSS_BEGIN
typedef struct SSS_DLL _tagCollisionArea
{
	Vector3 vMin;
	Vector3 vMax;
	Vector3 vSize;
	Vector3 vRenderMin;
	Vector3 vRenderMax;

	_tagCollisionArea() :
		vMin(),
		vMax(),
		vSize(),
		vRenderMin(),
		vRenderMax()
	{
	}
}COLLISIONAREA, *PCOLLISIONAREA;



class SSS_DLL CCollider :
	public CComponent
{
private:
	friend class CCollisionManager;

public:
	CCollider();
	CCollider(const CCollider& component);
	virtual ~CCollider();



protected:
	class PxRigidActor* m_pActor;
	class PxShape* m_pShape; // �ڽ� Ŭ�������� �����ϰ� �θ� �Ҹ��ڿ��� ����.
	class PxMaterial* m_pPhysicsMaterial;

	void ToDynamicCollider();
	void ToStaticCollider();
	void ToKinematicCollider();

public:
	void SetPhysicsMaterial(float fStaticFriction, float fDynamicFriction, float fRestitution);
	class PxMaterial* GetPhysicsMaterial() const;
	void SetStaticFriction(float fStaticFriction);
	void SetDynamicFriction(float fDynamicFriction);
	void SetRestitution(float fRestitution);
	float GetStaticFriction() const;
	float GetDynamicFriction() const;
	float GetRestitution() const;

protected:
	COLLIDER_TYPE m_eColliderType;
	Vector3 m_vLocalPosition;
	COLLISIONAREA m_tCollisionArea;
	
	list<class CCollisionVoxel2D*> m_CollisionVoxel2DList;
	list<class CCollisionVoxel3D*> m_CollisionVoxel3DList;
	unordered_map<class CCollider*, class CCollider*> m_mapCollision;

#ifdef _DEBUG

	class CShader*			m_pShader;
	class CMesh*				m_pMesh;
	class CSampler*			m_pSampler;
	ID3D11InputLayout*	m_pLayout;
	class CRenderState*	m_pRenderState[RS_END];
	Vector4						m_vColliderColor;

#endif // _DEBUG

#ifdef _DEBUG
protected:
	void SetRenderState(const string & strKey);
	void SetSampler();
	
public:

#endif // _DEBUG
	
public:
	COLLIDER_TYPE GetColliderType() const;
	Vector3 GetCenter() const;
	Vector3 GetLocalPosition() const;
	void SetDebugColor(const Vector4& vColor);

public:
	void Straighten();
	void SetLocalPosition(const Vector3& vLocalPosition);
	void SetLocalPosition(float x, float y, float z);

	virtual void SetCollisionVoxel() = 0; // �浹�� �Ϸ��� �ݵ�� ���ǵǾ�� �Ѵ�.
	void ClearCollisionVoxel();

	size_t GetCollisionCount() const;
	void AddCollisionList(CCollider* pTarget);
	void RemoveTargetFromCollisionList(CCollider* pTarget);
	bool ContainCollision(CCollider* pTarget) const;
	void ClearCollisionList();
	void AddCollisionVoxel(class CCollisionVoxel2D* pVoxel);
	void AddCollisionVoxel(class CCollisionVoxel3D* pVoxel);
	void AddCollisionVoxel(const Vector2& vVoxelKey);
	void AddCollisionVoxel(const Vector3& vVoxelKey);

	void CalculateCollision2D(float  fTime);
	void CalculateCollision3D(float  fTime);

	bool CollisionCheck(CCollider* pTarget) const;
	CCollider* GetColliderInBegin() const;

public:
	bool Initialize() override;
	int Update(float fTime) override;
	int LateUpdate(float fTime) override;
	int OnCollisionEnter(CCollider* pThis, CCollider* pTarget, float fTime) override;
	int OnCollisionStay(CCollider* pThis, CCollider* pTarget, float fTime) override;
	int OnCollisionExit(CCollider* pThis, CCollider* pTarget, float fTime) override;
	void RenderDebug(float fTime) override;
};

SSS_END