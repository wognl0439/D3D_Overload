#include "Physics.h"
#include "Transform.h"
#include "SceneManager.h"
#include "CollisionManager.h"
#include "CollisionVoxel2D.h"
#include "CollisionVoxel3D.h"
#include "Collider.h"
#include "Component\SphereCollider.h"
#include "Component\BoxCollider.h"


SSS_USING

DEFINITION_SINGLE(CPhysics)

CPhysics::CPhysics()
{
}

CPhysics::~CPhysics()
{
}


CCollider * CPhysics::RayCast(const Vector3 & vOrigin, const Vector3& vDirection, const Vector4 & vColor, Vector3* pIntersectPosition)
{
	//Scene ���� ��ü �浹ü�� ������ �Ҵ�Ǿ��� �浹 ������ ������ �޾ƿ�
	CScene* pScene = GET_SINGLE(CSceneManager)->GetCurrentScene();

	if (!pScene)
		return NULL;

	size_t iColliderCount = pScene->GetColliderList()->size();
	size_t iVoxelCount = GET_SINGLE(CCollisionManager)->GetVoxel3DCount();

	if (iColliderCount == 0)
	{
		SAFE_RELEASE(pScene);
		return NULL;
	}

	//�浹ü�� ������ �浹 ������ �������� ������ �浹ü�� ���� ĳ���� ��.
	//���ʿ��� ���ǰ� AABB to RAY ������ �� �ʿ䰡 ���� ����.
	
	if (iColliderCount < iVoxelCount)
	{
		vector<_tagIntersectedCollider> vecColliders;
		list<CCollider*>::const_iterator iter;
		list<CCollider*>::const_iterator iterEnd = pScene->GetColliderList()->end();

		for (iter = pScene->GetColliderList()->begin(); iter != iterEnd; ++iter)
		{			
			CTransform* pTransform = (*iter)->GetTransform();
			float fDistance = (vOrigin - pTransform->GetWorldPosition()).Length();
			SAFE_RELEASE(pTransform);

			_tagIntersectedCollider tCollider;
			tCollider.pTarget = *iter;
			tCollider.fDistanceFromOrigin = fDistance;
			vecColliders.push_back(tCollider);
		}
		//�Ÿ������� ����
		sort(vecColliders.begin(), vecColliders.end(), CPhysics::SortColliderFromDistance);

		size_t iSize = vecColliders.size();

		for (size_t i = 0 ; i < iSize ; ++i)
		{
			if (IntersectRay(vOrigin, vDirection, vecColliders[i].pTarget, pIntersectPosition))
			{
				SAFE_RELEASE(pScene);
				return vecColliders[i].pTarget;
			}
		}
	}
	else
	{
		//������Ʈ�� �Ÿ����� ���� �ؾ���;


		Vector3 vVoxelSize = GET_SINGLE(CCollisionManager)->GetVoxelSize3D();
		vector<_tagIntersectedVoxel> vecIntersectedVoxel;
		
		{
			unordered_map<Vector3, CCollisionVoxel3D*>::const_iterator iter;
			unordered_map<Vector3, CCollisionVoxel3D*>::const_iterator iterEnd = GET_SINGLE(CCollisionManager)->GetVoxel3D().end();

			for (iter = GET_SINGLE(CCollisionManager)->GetVoxel3D().begin(); iter != iterEnd; ++iter)
			{
				Vector3 vOutput;
				if (IntersectRayAxisAlignedBox(vOrigin, vDirection, iter->first, vVoxelSize, &vOutput))
				{
					//���� ������ ��ġ�� ���������� �浹ü�� �������� �ʴ� ��찡 �����ϰų�
					//�浹ü�� �����ϴ��� ������ �浹ü�� �浹�� ���� �ʴ� ��찡 �����ϰ�
					//�浹ü�� ������ ���ǵ� �������� �����Ƿ� 
					//�������� ��� �浹������ ���ƾ��Ѵ�. 
					//��δ�..
					_tagIntersectedVoxel tInfo = {};
					tInfo.fDistanceFromOrigin = (vOrigin - vOutput).Length();
					tInfo.pTarget = iter->second;
					vecIntersectedVoxel.push_back(tInfo);
				}
			}
		}
		//�Ÿ� ������ �����Ѵ�.
		sort(vecIntersectedVoxel.begin(), vecIntersectedVoxel.end(), CPhysics::SortVoxelFromDistance);


		//���� �Ǿ� �����Ƿ� ���� �浹 �ϴ� �༮�� ����ȴٸ� �������´�.
		size_t iSize = vecIntersectedVoxel.size();
		for (size_t i = 0; i < iSize; ++i)
		{
			unordered_map<CCollider*, CCollider*>::const_iterator iter;
			unordered_map<CCollider*, CCollider*>::const_iterator iterEnd = vecIntersectedVoxel[i].pTarget->GetContainedColliders()->end();

			for (iter = vecIntersectedVoxel[i].pTarget->GetContainedColliders()->begin(); iter != iterEnd; ++iter)
			{
				if (IntersectRay(vOrigin, vDirection, iter->second, pIntersectPosition))
				{
					SAFE_RELEASE(pScene);
					return iter->second;
				}				
			}			
		}
	}
	//�浹 ������ Origin �������� 

	SAFE_RELEASE(pScene);
	return NULL;
}

CCollider * CPhysics::RayCast(RAY tRay, Vector3* pIntersectPosition)
{
	return RayCast(tRay.vOrigin, tRay.vDirection, tRay.vColor, pIntersectPosition);
}

bool CPhysics::IntersectRay(const Vector3& vRayOrigin, const Vector3& vRayDirection, CCollider * pTargetCollider, Vector3* pPosition)
{
	COLLIDER_TYPE eType = pTargetCollider->GetColliderType();

	switch (eType)
	{
	case SSS::CT_SPHERE:
	{
		CSphereCollider* pCollider = dynamic_cast<CSphereCollider*>(pTargetCollider);
		Vector3 vCenter = pCollider->GetCenter();
		float fRadius = pCollider->GetRadius();
		return IntersectRaySphere(vRayOrigin, vRayDirection, vCenter, fRadius, pPosition);
	}
		break;
	case SSS::CT_BOX:
	{
		CBoxCollider* pCollider = dynamic_cast<CBoxCollider*>(pTargetCollider);
		CTransform* pTransform = pCollider->GetTransform();
		Vector3 vCenter = pCollider->GetCenter();
		Vector3 vRotation = pTransform->GetWorldRotation();
		Vector3 vVolume = (pCollider->GetVolume() / 2.0f) * pTransform->GetWorldScale();
		SAFE_RELEASE(pTransform);

		return IntersectRayOrientedBox(vRayOrigin, vRayDirection, vCenter, vVolume, vRotation, pPosition);
	}
		break;
	case SSS::CT_MESH:
		break;
	case SSS::CT_TERRAIN:
		break;
	default:
		break;
	}


}

bool CPhysics::SortVoxelFromDistance(_tagIntersectedVoxel tVoxelA, _tagIntersectedVoxel tVoxelB)
{
	return tVoxelA.fDistanceFromOrigin <tVoxelB.fDistanceFromOrigin;
}

bool CPhysics::SortColliderFromDistance(_tagIntersectedCollider tColliderA, _tagIntersectedCollider tColliderB)
{
	return tColliderA.fDistanceFromOrigin < tColliderB.fDistanceFromOrigin;
}


bool CPhysics::XMVector3AnyTrue(const XMVECTOR & v)
{
	XMVECTOR C = XMVectorSwizzle(v, 0, 1, 2, 0);
	return XMComparisonAnyTrue(XMVector4EqualIntR(C, XMVectorTrueInt()));
}

bool CPhysics::IntersectRayDisk(const Vector3 & Origin, const Vector3 & Direction, const Vector3 & vDiskCenter, const Vector3 & vDiskRotation, float fDiskRadius, Vector3 * pPosition)
{
	bool bResult = IntersectRayPlane(Origin, Direction, vDiskCenter, Vector2(fDiskRadius, fDiskRadius), vDiskRotation, pPosition);

	if (bResult)
	{
		float fDistance = (vDiskCenter - *pPosition).Length();
		if (fDistance < fDiskRadius)
		{
			return true;
		}
	}

	return false;
}

bool CPhysics::IntersectRayPlane(const Vector3 & Origin, const Vector3 & Direction, const Vector3 & vPlaneCenter, const Vector2 & vPlaneVolume, const Vector3 & vPlaneRotation, Vector3 * pPosition)
{
	return IntersectRayOrientedBox(Origin, Direction, vPlaneCenter, Vector3(vPlaneVolume.x, 0, vPlaneVolume.y), vPlaneRotation, pPosition );
}

bool CPhysics::IntersectRayTriangle(const Vector3 & Origin, const Vector3 & Direction, const Vector3 & V0, const Vector3 & V1, const Vector3 & V2, Vector3 * pPosition)
{
	return false;
}

bool CPhysics::IntersectRaySphere(const Vector3 & Origin, const Vector3 & vDirection, const Vector3 & vSphereCenter, float fRadius, Vector3 * pPosition)
{
	Vector3 vLength = vSphereCenter - Origin;

	XMVECTOR s = XMVectorReplicate(vLength.Dot(vDirection));
	XMVECTOR l2 = XMVectorReplicate(vLength.Dot(vLength));
	XMVECTOR r2 = XMVectorReplicate(fRadius * fRadius);
	XMVECTOR m2 = l2 - s * s;
	XMVECTOR NoIntersection;

	NoIntersection = XMVectorAndInt(XMVectorLess(s, XMVectorZero()), XMVectorGreater(l2, r2));
	NoIntersection = XMVectorOrInt(NoIntersection, XMVectorGreater(m2, r2));

	XMVECTOR q = XMVectorSqrt(r2 - m2);
	XMVECTOR t1 = s - q;
	XMVECTOR t2 = s + q;

	XMVECTOR OriginInside = XMVectorLessOrEqual(l2, r2);
	XMVECTOR t = XMVectorSelect(t1, t2, OriginInside);

	if (XMVector4NotEqualInt(NoIntersection, XMVectorTrueInt()))
	{
		if (pPosition)
		{
			Vector3 vResult = Origin + vDirection * t;
			memcpy(pPosition, &vResult, sizeof(Vector3));
		}
		return true;
	}
	return false;
}

bool CPhysics::IntersectRayAxisAlignedBox(const Vector3 & vOrigin, const Vector3 & vDirection, const Vector3 & vCenter, const Vector3 & vVolume, Vector3 * pPosition)
{
	static const XMVECTOR Epsilon =
	{
		1e-20f, 1e-20f, 1e-20f, 1e-20f
	};
	static const XMVECTOR FltMin =
	{
		-FLT_MAX, -FLT_MAX, -FLT_MAX, -FLT_MAX
	};
	static const XMVECTOR FltMax =
	{
		FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX
	};

	// Load the box.
	XMVECTOR Center = vCenter.Convert();
	XMVECTOR Extents = vVolume.Convert();

	// Adjust ray origin to be relative to center of the box.
	XMVECTOR TOrigin = Center - vOrigin.Convert();

	// Compute the dot product againt each axis of the box.
	// Since the axii are (1,0,0), (0,1,0), (0,0,1) no computation is necessary.
	XMVECTOR AxisDotOrigin = TOrigin;
	XMVECTOR AxisDotDirection = vDirection.Convert();

	// if (fabs(AxisDotDirection) <= Epsilon) the ray is nearly parallel to the slab.
	XMVECTOR IsParallel = XMVectorLessOrEqual(XMVectorAbs(AxisDotDirection), Epsilon);

	// Test against all three axii simultaneously.
	XMVECTOR InverseAxisDotDirection = XMVectorReciprocal(AxisDotDirection);
	XMVECTOR t1 = (AxisDotOrigin - Extents) * InverseAxisDotDirection;
	XMVECTOR t2 = (AxisDotOrigin + Extents) * InverseAxisDotDirection;

	// Compute the max of min(t1,t2) and the min of max(t1,t2) ensuring we don't
	// use the results from any directions parallel to the slab.
	XMVECTOR t_min = XMVectorSelect(XMVectorMin(t1, t2), FltMin, IsParallel);
	XMVECTOR t_max = XMVectorSelect(XMVectorMax(t1, t2), FltMax, IsParallel);

	// t_min.x = maximum( t_min.x, t_min.y, t_min.z );
	// t_max.x = minimum( t_max.x, t_max.y, t_max.z );
	t_min = XMVectorMax(t_min, XMVectorSplatY(t_min));  // x = max(x,y)
	t_min = XMVectorMax(t_min, XMVectorSplatZ(t_min));  // x = max(max(x,y),z)
	t_max = XMVectorMin(t_max, XMVectorSplatY(t_max));  // x = min(x,y)
	t_max = XMVectorMin(t_max, XMVectorSplatZ(t_max));  // x = min(min(x,y),z)

														// if ( t_min > t_max ) return FALSE;
	XMVECTOR NoIntersection = XMVectorGreater(XMVectorSplatX(t_min), XMVectorSplatX(t_max));

	// if ( t_max < 0.0f ) return FALSE;
	NoIntersection = XMVectorOrInt(NoIntersection, XMVectorLess(XMVectorSplatX(t_max), XMVectorZero()));

	// if (IsParallel && (-Extents > AxisDotOrigin || Extents < AxisDotOrigin)) return FALSE;
	XMVECTOR ParallelOverlap = XMVectorInBounds(AxisDotOrigin, Extents);
	NoIntersection = XMVectorOrInt(NoIntersection, XMVectorAndCInt(IsParallel, ParallelOverlap));



	if (!XMVector3AnyTrue(NoIntersection))
	{
		if (pPosition)
		{
			Vector3 vResult = vOrigin + vDirection * t_min;
			memcpy(pPosition, &vResult, sizeof(Vector3));
		}
		return true;
	}

	return false;
}

bool CPhysics::IntersectRayOrientedBox(const Vector3 & Origin, const Vector3 & Direction, const Vector3 & vCenter, const Vector3 & vVolume, const Vector3 & vRotation, Vector3 * pPosition)
{
	static const XMVECTOR Epsilon =
	{
		1e-20f, 1e-20f, 1e-20f, 1e-20f
	};
	static const XMVECTOR FltMin =
	{
		-FLT_MAX, -FLT_MAX, -FLT_MAX, -FLT_MAX
	};
	static const XMVECTOR FltMax =
	{
		FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX
	};
	static const XMVECTORI32 SelectY =
	{
		XM_SELECT_0, XM_SELECT_1, XM_SELECT_0, XM_SELECT_0
	};
	static const XMVECTORI32 SelectZ =
	{
		XM_SELECT_0, XM_SELECT_0, XM_SELECT_1, XM_SELECT_0
	};

	// Load the box.
	XMVECTOR Center = vCenter.Convert();
	XMVECTOR Extents = vVolume.Convert();
	XMVECTOR Orientation = XMQuaternionRotationRollPitchYawFromVector(vRotation.Convert());
	XMQuaternionNormalize(Orientation);


	// Get the boxes normalized side directions.
	XMMATRIX R = XMMatrixRotationQuaternion(Orientation);

	// Adjust ray origin to be relative to center of the box.
	XMVECTOR TOrigin = Center - Origin.Convert();

	// Compute the dot product againt each axis of the box.
	XMVECTOR AxisDotOrigin = XMVector3Dot(R.r[0], TOrigin);
	AxisDotOrigin = XMVectorSelect(AxisDotOrigin, XMVector3Dot(R.r[1], TOrigin), SelectY);
	AxisDotOrigin = XMVectorSelect(AxisDotOrigin, XMVector3Dot(R.r[2], TOrigin), SelectZ);

	XMVECTOR AxisDotDirection = XMVector3Dot(R.r[0], Direction.Convert());
	AxisDotDirection = XMVectorSelect(AxisDotDirection, XMVector3Dot(R.r[1], Direction.Convert()), SelectY);
	AxisDotDirection = XMVectorSelect(AxisDotDirection, XMVector3Dot(R.r[2], Direction.Convert()), SelectZ);

	// if (fabs(AxisDotDirection) <= Epsilon) the ray is nearly parallel to the slab.
	XMVECTOR IsParallel = XMVectorLessOrEqual(XMVectorAbs(AxisDotDirection), Epsilon);

	// Test against all three axes simultaneously.
	XMVECTOR InverseAxisDotDirection = XMVectorReciprocal(AxisDotDirection);
	XMVECTOR t1 = (AxisDotOrigin - Extents) * InverseAxisDotDirection;
	XMVECTOR t2 = (AxisDotOrigin + Extents) * InverseAxisDotDirection;

	// Compute the max of min(t1,t2) and the min of max(t1,t2) ensuring we don't
	// use the results from any directions parallel to the slab.
	XMVECTOR t_min = XMVectorSelect(XMVectorMin(t1, t2), FltMin, IsParallel);
	XMVECTOR t_max = XMVectorSelect(XMVectorMax(t1, t2), FltMax, IsParallel);

	// t_min.x = maximum( t_min.x, t_min.y, t_min.z );
	// t_max.x = minimum( t_max.x, t_max.y, t_max.z );
	t_min = XMVectorMax(t_min, XMVectorSplatY(t_min));  // x = max(x,y)
	t_min = XMVectorMax(t_min, XMVectorSplatZ(t_min));  // x = max(max(x,y),z)
	t_max = XMVectorMin(t_max, XMVectorSplatY(t_max));  // x = min(x,y)
	t_max = XMVectorMin(t_max, XMVectorSplatZ(t_max));  // x = min(min(x,y),z)

														// if ( t_min > t_max ) return FALSE;
	XMVECTOR NoIntersection = XMVectorGreater(XMVectorSplatX(t_min), XMVectorSplatX(t_max));

	// if ( t_max < 0.0f ) return FALSE;
	NoIntersection = XMVectorOrInt(NoIntersection, XMVectorLess(XMVectorSplatX(t_max), XMVectorZero()));

	// if (IsParallel && (-Extents > AxisDotOrigin || Extents < AxisDotOrigin)) return FALSE;
	XMVECTOR ParallelOverlap = XMVectorInBounds(AxisDotOrigin, Extents);
	NoIntersection = XMVectorOrInt(NoIntersection, XMVectorAndCInt(IsParallel, ParallelOverlap));

	if (!XMVector3AnyTrue(NoIntersection))
	{
		if (pPosition)
		{
			Vector3 vResult = Origin + Direction * t_min;
			memcpy(pPosition, &vResult, sizeof(Vector3));
		}
		return true;
	}

	return false;
}

bool CPhysics::IntersectSphereSphere(const Vector3 & vCenterA, float fRadiusA, const Vector3 & vCenterB, float fRadiusB)
{
	XMVECTOR Delta = vCenterB - vCenterA;
	XMVECTOR DistanceSquared = XMVector3LengthSq(Delta);
	XMVECTOR RadiusSquared = XMVectorReplicate(fRadiusA + fRadiusB);
	RadiusSquared = RadiusSquared * RadiusSquared;
	return XMVector4LessOrEqual(DistanceSquared, RadiusSquared);
}

bool CPhysics::IntersectSphereAxisAlignedBox(const Vector3 & vCenterA, float fRadiusA, const Vector3 & vLT, const Vector3 & vRB)
{
	return false;
}

bool CPhysics::IntersectSphereOrientedBox(const Vector3 & vSphereCenter, float fRadius, const Vector3 & vCenter, const Vector3 & vVolume, const Vector3 & vRotation)
{
	XMVECTOR SphereCenter = vSphereCenter.Convert();
	XMVECTOR SphereRadius = XMVectorReplicate(fRadius);

	XMVECTOR BoxCenter = vCenter.Convert();
	XMVECTOR BoxExtents = vVolume.Convert();
	XMVECTOR BoxOrientation = Vector3::ToQuaternion(vRotation);

	XMQuaternionNormalize(BoxOrientation);

	// Transform the center of the sphere to be local to the box.
	// BoxMin = -BoxExtents
	// BoxMax = +BoxExtents
	SphereCenter = XMVector3InverseRotate(SphereCenter - BoxCenter, BoxOrientation);

	// Find the distance to the nearest point on the box.
	// for each i in (x, y, z)
	// if (SphereCenter(i) < BoxMin(i)) d2 += (SphereCenter(i) - BoxMin(i)) ^ 2
	// else if (SphereCenter(i) > BoxMax(i)) d2 += (SphereCenter(i) - BoxMax(i)) ^ 2

	XMVECTOR d = XMVectorZero();

	// Compute d for each dimension.
	XMVECTOR LessThanMin = XMVectorLess(SphereCenter, -BoxExtents);
	XMVECTOR GreaterThanMax = XMVectorGreater(SphereCenter, BoxExtents);

	XMVECTOR MinDelta = SphereCenter + BoxExtents;
	XMVECTOR MaxDelta = SphereCenter - BoxExtents;

	// Choose value for each dimension based on the comparison.
	d = XMVectorSelect(d, MinDelta, LessThanMin);
	d = XMVectorSelect(d, MaxDelta, GreaterThanMax);

	// Use a dot-product to square them and sum them together.
	XMVECTOR d2 = XMVector3Dot(d, d);

	return XMVector4LessOrEqual(d2, XMVectorMultiply(SphereRadius, SphereRadius));
}

bool CPhysics::IntersectAxisAlignedBoxAxisAlignedBox(const Vector3 & vLTA, const Vector3 & vRBA, const Vector3 & vLTB, const Vector3 & vRBB)
{
	return false;
}

bool CPhysics::IntersectAxisAlignedBoxOrientedBox(const Vector3 & vLTA, const Vector3 & vRBA, const Vector3 & vLTB, const Vector3 & vRBB, const Vector3 & vRotationB)
{
	return false;
}

bool CPhysics::IntersectOrientedBoxOrientedBox(const Vector3 & vCenterA, const Vector3 & vVolumeA, const Vector3 & vRotationA, const Vector3 & vCenterB, const Vector3 & vVolumeB, const Vector3 & vRotationB)
{
		static const XMVECTORI32 Permute0W1Z0Y0X =
		{
			XM_PERMUTE_0W, XM_PERMUTE_1Z, XM_PERMUTE_0Y, XM_PERMUTE_0X
		};
		static const XMVECTORI32 Permute0Z0W1X0Y =
		{
			XM_PERMUTE_0Z, XM_PERMUTE_0W, XM_PERMUTE_1X, XM_PERMUTE_0Y
		};
		static const XMVECTORI32 Permute1Y0X0W0Z =
		{
			XM_PERMUTE_1Y, XM_PERMUTE_0X, XM_PERMUTE_0W, XM_PERMUTE_0Z
		};
		static const XMVECTORI32 PermuteWZYX =
		{
			XM_PERMUTE_0W, XM_PERMUTE_0Z, XM_PERMUTE_0Y, XM_PERMUTE_0X
		};
		static const XMVECTORI32 PermuteZWXY =
		{
			XM_PERMUTE_0Z, XM_PERMUTE_0W, XM_PERMUTE_0X, XM_PERMUTE_0Y
		};
		static const XMVECTORI32 PermuteYXWZ =
		{
			XM_PERMUTE_0Y, XM_PERMUTE_0X, XM_PERMUTE_0W, XM_PERMUTE_0Z
		};

		//Convert Euler Angle to Quaternion XMVERTOR
		XMVECTOR vQuaternionA = Vector3::ToQuaternion(vRotationA);
		XMVECTOR vQuaternionB = Vector3::ToQuaternion(vRotationB);
		
		vQuaternionA = XMQuaternionNormalize(vQuaternionA);
		vQuaternionB = XMQuaternionNormalize(vQuaternionB);
		
		XMVECTOR Q = XMQuaternionMultiply(vQuaternionA, XMQuaternionConjugate(vQuaternionB));
		XMMATRIX R = XMMatrixRotationQuaternion(Q);

		// Compute the translation of B relative to A.
		XMVECTOR A_cent = vCenterA.Convert();
		XMVECTOR B_cent = vCenterB.Convert();
		XMVECTOR t = XMVector3InverseRotate(B_cent - A_cent, vQuaternionA);

		//
		// h(A) = extents of A.
		// h(B) = extents of B.
		//
		// a(u) = axes of A = (1,0,0), (0,1,0), (0,0,1)
		// b(u) = axes of B relative to A = (r00,r10,r20), (r01,r11,r21), (r02,r12,r22)
		//  
		// For each possible separating axis l:
		//   d(A) = sum (for i = u,v,w) h(A)(i) * abs( a(i) dot l )
		//   d(B) = sum (for i = u,v,w) h(B)(i) * abs( b(i) dot l )
		//   if abs( t dot l ) > d(A) + d(B) then disjoint
		//

		// Load extents of A and B.
		XMVECTOR h_A = vVolumeA.Convert();
		XMVECTOR h_B = vVolumeB.Convert();

		// Rows. Note R[0,1,2]X.w = 0.
		XMVECTOR R0X = R.r[0];
		XMVECTOR R1X = R.r[1];
		XMVECTOR R2X = R.r[2];

		R = XMMatrixTranspose(R);

		// Columns. Note RX[0,1,2].w = 0.
		XMVECTOR RX0 = R.r[0];
		XMVECTOR RX1 = R.r[1];
		XMVECTOR RX2 = R.r[2];

		// Absolute value of rows.
		XMVECTOR AR0X = XMVectorAbs(R0X);
		XMVECTOR AR1X = XMVectorAbs(R1X);
		XMVECTOR AR2X = XMVectorAbs(R2X);

		// Absolute value of columns.
		XMVECTOR ARX0 = XMVectorAbs(RX0);
		XMVECTOR ARX1 = XMVectorAbs(RX1);
		XMVECTOR ARX2 = XMVectorAbs(RX2);

		// Test each of the 15 possible seperating axii.
		XMVECTOR d, d_A, d_B;

		// l = a(u) = (1, 0, 0)
		// t dot l = t.x
		// d(A) = h(A).x
		// d(B) = h(B) dot abs(r00, r01, r02)
		d = XMVectorSplatX(t);
		d_A = XMVectorSplatX(h_A);
		d_B = XMVector3Dot(h_B, AR0X);
		XMVECTOR NoIntersection = XMVectorGreater(XMVectorAbs(d), XMVectorAdd(d_A, d_B));

		// l = a(v) = (0, 1, 0)
		// t dot l = t.y
		// d(A) = h(A).y
		// d(B) = h(B) dot abs(r10, r11, r12)
		d = XMVectorSplatY(t);
		d_A = XMVectorSplatY(h_A);
		d_B = XMVector3Dot(h_B, AR1X);
		NoIntersection = XMVectorOrInt(NoIntersection,
			XMVectorGreater(XMVectorAbs(d), XMVectorAdd(d_A, d_B)));

		// l = a(w) = (0, 0, 1)
		// t dot l = t.z
		// d(A) = h(A).z
		// d(B) = h(B) dot abs(r20, r21, r22)
		d = XMVectorSplatZ(t);
		d_A = XMVectorSplatZ(h_A);
		d_B = XMVector3Dot(h_B, AR2X);
		NoIntersection = XMVectorOrInt(NoIntersection,
			XMVectorGreater(XMVectorAbs(d), XMVectorAdd(d_A, d_B)));

		// l = b(u) = (r00, r10, r20)
		// d(A) = h(A) dot abs(r00, r10, r20)
		// d(B) = h(B).x
		d = XMVector3Dot(t, RX0);
		d_A = XMVector3Dot(h_A, ARX0);
		d_B = XMVectorSplatX(h_B);
		NoIntersection = XMVectorOrInt(NoIntersection,
			XMVectorGreater(XMVectorAbs(d), XMVectorAdd(d_A, d_B)));

		// l = b(v) = (r01, r11, r21)
		// d(A) = h(A) dot abs(r01, r11, r21)
		// d(B) = h(B).y
		d = XMVector3Dot(t, RX1);
		d_A = XMVector3Dot(h_A, ARX1);
		d_B = XMVectorSplatY(h_B);
		NoIntersection = XMVectorOrInt(NoIntersection,
			XMVectorGreater(XMVectorAbs(d), XMVectorAdd(d_A, d_B)));

		// l = b(w) = (r02, r12, r22)
		// d(A) = h(A) dot abs(r02, r12, r22)
		// d(B) = h(B).z
		d = XMVector3Dot(t, RX2);
		d_A = XMVector3Dot(h_A, ARX2);
		d_B = XMVectorSplatZ(h_B);
		NoIntersection = XMVectorOrInt(NoIntersection,
			XMVectorGreater(XMVectorAbs(d), XMVectorAdd(d_A, d_B)));

		// l = a(u) x b(u) = (0, -r20, r10)
		// d(A) = h(A) dot abs(0, r20, r10)
		// d(B) = h(B) dot abs(0, r02, r01)
		d = XMVector3Dot(t, XMVectorPermute(RX0, -RX0, Permute0W1Z0Y0X));
		d_A = XMVector3Dot(h_A, XMVectorPermute(ARX0, ARX0, PermuteWZYX));
		d_B = XMVector3Dot(h_B, XMVectorPermute(AR0X, AR0X, PermuteWZYX));
		NoIntersection = XMVectorOrInt(NoIntersection,
			XMVectorGreater(XMVectorAbs(d), XMVectorAdd(d_A, d_B)));

		// l = a(u) x b(v) = (0, -r21, r11)
		// d(A) = h(A) dot abs(0, r21, r11)
		// d(B) = h(B) dot abs(r02, 0, r00)
		d = XMVector3Dot(t, XMVectorPermute(RX1, -RX1, Permute0W1Z0Y0X));
		d_A = XMVector3Dot(h_A, XMVectorPermute(ARX1, ARX1, PermuteWZYX));
		d_B = XMVector3Dot(h_B, XMVectorPermute(AR0X, AR0X, PermuteZWXY));
		NoIntersection = XMVectorOrInt(NoIntersection,
			XMVectorGreater(XMVectorAbs(d), XMVectorAdd(d_A, d_B)));

		// l = a(u) x b(w) = (0, -r22, r12)
		// d(A) = h(A) dot abs(0, r22, r12)
		// d(B) = h(B) dot abs(r01, r00, 0)
		d = XMVector3Dot(t, XMVectorPermute(RX2, -RX2, Permute0W1Z0Y0X));
		d_A = XMVector3Dot(h_A, XMVectorPermute(ARX2, ARX2, PermuteWZYX));
		d_B = XMVector3Dot(h_B, XMVectorPermute(AR0X, AR0X, PermuteYXWZ));
		NoIntersection = XMVectorOrInt(NoIntersection,
			XMVectorGreater(XMVectorAbs(d), XMVectorAdd(d_A, d_B)));

		// l = a(v) x b(u) = (r20, 0, -r00)
		// d(A) = h(A) dot abs(r20, 0, r00)
		// d(B) = h(B) dot abs(0, r12, r11)
		d = XMVector3Dot(t, XMVectorPermute(RX0, -RX0, Permute0Z0W1X0Y));
		d_A = XMVector3Dot(h_A, XMVectorPermute(ARX0, ARX0, PermuteZWXY));
		d_B = XMVector3Dot(h_B, XMVectorPermute(AR1X, AR1X, PermuteWZYX));
		NoIntersection = XMVectorOrInt(NoIntersection,
			XMVectorGreater(XMVectorAbs(d), XMVectorAdd(d_A, d_B)));

		// l = a(v) x b(v) = (r21, 0, -r01)
		// d(A) = h(A) dot abs(r21, 0, r01)
		// d(B) = h(B) dot abs(r12, 0, r10)
		d = XMVector3Dot(t, XMVectorPermute(RX1, -RX1, Permute0Z0W1X0Y));
		d_A = XMVector3Dot(h_A, XMVectorPermute(ARX1, ARX1, PermuteZWXY));
		d_B = XMVector3Dot(h_B, XMVectorPermute(AR1X, AR1X, PermuteZWXY));
		NoIntersection = XMVectorOrInt(NoIntersection,
			XMVectorGreater(XMVectorAbs(d), XMVectorAdd(d_A, d_B)));

		// l = a(v) x b(w) = (r22, 0, -r02)
		// d(A) = h(A) dot abs(r22, 0, r02)
		// d(B) = h(B) dot abs(r11, r10, 0)
		d = XMVector3Dot(t, XMVectorPermute(RX2, -RX2, Permute0Z0W1X0Y));
		d_A = XMVector3Dot(h_A, XMVectorPermute(ARX2, ARX2, PermuteZWXY));
		d_B = XMVector3Dot(h_B, XMVectorPermute(AR1X, AR1X, PermuteYXWZ));
		NoIntersection = XMVectorOrInt(NoIntersection,
			XMVectorGreater(XMVectorAbs(d), XMVectorAdd(d_A, d_B)));

		// l = a(w) x b(u) = (-r10, r00, 0)
		// d(A) = h(A) dot abs(r10, r00, 0)
		// d(B) = h(B) dot abs(0, r22, r21)
		d = XMVector3Dot(t, XMVectorPermute(RX0, -RX0, Permute1Y0X0W0Z));
		d_A = XMVector3Dot(h_A, XMVectorPermute(ARX0, ARX0, PermuteYXWZ));
		d_B = XMVector3Dot(h_B, XMVectorPermute(AR2X, AR2X, PermuteWZYX));
		NoIntersection = XMVectorOrInt(NoIntersection,
			XMVectorGreater(XMVectorAbs(d), XMVectorAdd(d_A, d_B)));

		// l = a(w) x b(v) = (-r11, r01, 0)
		// d(A) = h(A) dot abs(r11, r01, 0)
		// d(B) = h(B) dot abs(r22, 0, r20)
		d = XMVector3Dot(t, XMVectorPermute(RX1, -RX1, Permute1Y0X0W0Z));
		d_A = XMVector3Dot(h_A, XMVectorPermute(ARX1, ARX1, PermuteYXWZ));
		d_B = XMVector3Dot(h_B, XMVectorPermute(AR2X, AR2X, PermuteZWXY));
		NoIntersection = XMVectorOrInt(NoIntersection,
			XMVectorGreater(XMVectorAbs(d), XMVectorAdd(d_A, d_B)));

		// l = a(w) x b(w) = (-r12, r02, 0)
		// d(A) = h(A) dot abs(r12, r02, 0)
		// d(B) = h(B) dot abs(r21, r20, 0)
		d = XMVector3Dot(t, XMVectorPermute(RX2, -RX2, Permute1Y0X0W0Z));
		d_A = XMVector3Dot(h_A, XMVectorPermute(ARX2, ARX2, PermuteYXWZ));
		d_B = XMVector3Dot(h_B, XMVectorPermute(AR2X, AR2X, PermuteYXWZ));
		NoIntersection = XMVectorOrInt(NoIntersection,
			XMVectorGreater(XMVectorAbs(d), XMVectorAdd(d_A, d_B)));

		// No seperating axis found, boxes must intersect.
		return XMVector4NotEqualInt(NoIntersection, XMVectorTrueInt());
}

int CPhysics::IntersectFrustumSphere(const Vector3 & vCenter, float fRadius, const Vector3& vFrustumOrigin, const Vector3& vFrustumRotation, float fHorizontalLength, float fVerticalLength, float fNearPlane, float fFarPlane)
{

	float fRightSlope = (fHorizontalLength / 2.0f) / fFarPlane;
	float fLeftSlope = fRightSlope;
	float fTopSlope = (fVerticalLength / 2.0f) / fFarPlane;
	float fBottomSlope = fTopSlope;

	XMVECTOR Zero = XMVectorZero();

	// Build the frustum planes.
	XMVECTOR Planes[6];
	Planes[0] = XMVectorSet(0.0f, 0.0f, -1.0f, fNearPlane);
	Planes[1] = XMVectorSet(0.0f, 0.0f, 1.0f, -fFarPlane);
	Planes[2] = XMVectorSet(1.0f, 0.0f, -fRightSlope, 0.0f);
	Planes[3] = XMVectorSet(-1.0f, 0.0f, fLeftSlope, 0.0f);
	Planes[4] = XMVectorSet(0.0f, 1.0f, -fTopSlope, 0.0f);
	Planes[5] = XMVectorSet(0.0f, -1.0f, fBottomSlope, 0.0f);

	// Normalize the planes so we can compare to the sphere radius.
	Planes[2] = XMVector3Normalize(Planes[2]);
	Planes[3] = XMVector3Normalize(Planes[3]);
	Planes[4] = XMVector3Normalize(Planes[4]);
	Planes[5] = XMVector3Normalize(Planes[5]);

	// Load origin and orientation of the frustum.
	XMVECTOR Origin = vFrustumOrigin.Convert();
	XMVECTOR Orientation = Vector3::ToQuaternion(vFrustumRotation);

	XMQuaternionNormalize(Orientation);

	// Load the sphere.
	XMVECTOR Center = vCenter.Convert();
	XMVECTOR Radius = XMVectorReplicate(fRadius);

	// Transform the center of the sphere into the local space of frustum.
	Center = XMVector3InverseRotate(Center - Origin, Orientation);

	// Set w of the center to one so we can dot4 with the plane.
	Center = XMVectorInsert(Center, XMVectorSplatOne(), 0, 0, 0, 0, 1);

	// Check against each plane of the frustum.
	XMVECTOR Outside = XMVectorFalseInt();
	XMVECTOR InsideAll = XMVectorTrueInt();
	XMVECTOR CenterInsideAll = XMVectorTrueInt();

	XMVECTOR Dist[6];

	for (INT i = 0; i < 6; i++)
	{
		Dist[i] = XMVector4Dot(Center, Planes[i]);

		// Outside the plane?
		Outside = XMVectorOrInt(Outside, XMVectorGreater(Dist[i], Radius));

		// Fully inside the plane?
		InsideAll = XMVectorAndInt(InsideAll, XMVectorLessOrEqual(Dist[i], -Radius));

		// Check if the center is inside the plane.
		CenterInsideAll = XMVectorAndInt(CenterInsideAll, XMVectorLessOrEqual(Dist[i], Zero));
	}

	// If the sphere is outside any of the planes it is outside. 
	if (XMVector4EqualInt(Outside, XMVectorTrueInt()))
		return 0;

	// If the sphere is inside all planes it is fully inside.
	if (XMVector4EqualInt(InsideAll, XMVectorTrueInt()))
		return 2;

	// If the center of the sphere is inside all planes and the sphere intersects 
	// one or more planes then it must intersect.
	if (XMVector4EqualInt(CenterInsideAll, XMVectorTrueInt()))
		return 1;

	// The sphere may be outside the frustum or intersecting the frustum.
	// Find the nearest feature (face, edge, or corner) on the frustum 
	// to the sphere.

	// The faces adjacent to each face are:
	static const INT adjacent_faces[6][4] =
	{
		{ 2, 3, 4, 5 },    // 0
		{ 2, 3, 4, 5 },    // 1
		{ 0, 1, 4, 5 },    // 2
		{ 0, 1, 4, 5 },    // 3
		{ 0, 1, 2, 3 },    // 4
		{ 0, 1, 2, 3 }
	};  // 5

	XMVECTOR Intersects = XMVectorFalseInt();

	// Check to see if the nearest feature is one of the planes.
	for (INT i = 0; i < 6; i++)
	{
		// Find the nearest point on the plane to the center of the sphere.
		XMVECTOR Point = Center - (Planes[i] * Dist[i]);

		// Set w of the point to one.
		Point = XMVectorInsert(Point, XMVectorSplatOne(), 0, 0, 0, 0, 1);

		// If the point is inside the face (inside the adjacent planes) then
		// this plane is the nearest feature.
		XMVECTOR InsideFace = XMVectorTrueInt();

		for (INT j = 0; j < 4; j++)
		{
			INT plane_index = adjacent_faces[i][j];

			InsideFace = XMVectorAndInt(InsideFace,
				XMVectorLessOrEqual(XMVector4Dot(Point, Planes[plane_index]), Zero));
		}

		// Since we have already checked distance from the plane we know that the
		// sphere must intersect if this plane is the nearest feature.
		Intersects = XMVectorOrInt(Intersects,
			XMVectorAndInt(XMVectorGreater(Dist[i], Zero), InsideFace));
	}

	if (XMVector4EqualInt(Intersects, XMVectorTrueInt()))
		return 1;

	// Build the corners of the frustum.
	XMVECTOR RightTop = XMVectorSet(fRightSlope, fTopSlope, 1.0f, 0.0f);
	XMVECTOR RightBottom = XMVectorSet(fRightSlope, fBottomSlope, 1.0f, 0.0f);
	XMVECTOR LeftTop = XMVectorSet(fLeftSlope, fTopSlope, 1.0f, 0.0f);
	XMVECTOR LeftBottom = XMVectorSet(fLeftSlope, fBottomSlope, 1.0f, 0.0f);
	XMVECTOR Near = XMVectorReplicate(fNearPlane);
	XMVECTOR Far = XMVectorReplicate(fFarPlane);

	XMVECTOR Corners[8];
	Corners[0] = RightTop * Near;
	Corners[1] = RightBottom * Near;
	Corners[2] = LeftTop * Near;
	Corners[3] = LeftBottom * Near;
	Corners[4] = RightTop * Far;
	Corners[5] = RightBottom * Far;
	Corners[6] = LeftTop * Far;
	Corners[7] = LeftBottom * Far;

	// The Edges are:
	static const INT edges[12][2] =
	{
		{ 0, 1 },{ 2, 3 },{ 0, 2 },{ 1, 3 },    // Near plane
		{ 4, 5 },{ 6, 7 },{ 4, 6 },{ 5, 7 },    // Far plane
		{ 0, 4 },{ 1, 5 },{ 2, 6 },{ 3, 7 },
	}; // Near to far

	XMVECTOR RadiusSq = Radius * Radius;

	// Check to see if the nearest feature is one of the edges (or corners).
	for (INT i = 0; i < 12; i++)
	{
		INT ei0 = edges[i][0];
		INT ei1 = edges[i][1];

		// Find the nearest point on the edge to the center of the sphere.
		// The corners of the frustum are included as the endpoints of the edges.
		XMVECTOR Point = PointOnLineSegmentNearestPoint(Corners[ei0], Corners[ei1], Center);

		XMVECTOR Delta = Center - Point;

		XMVECTOR DistSq = XMVector3Dot(Delta, Delta);

		// If the distance to the center of the sphere to the point is less than 
		// the radius of the sphere then it must intersect.
		Intersects = XMVectorOrInt(Intersects, XMVectorLessOrEqual(DistSq, RadiusSq));
	}

	if (XMVector4EqualInt(Intersects, XMVectorTrueInt()))
		return 1;

	// The sphere must be outside the frustum.
	return 0;
}

int CPhysics::IntersectFrustumAxisAlignedBox(const Vector3 & vLT, const Vector3 & vRB, const Vector3 & vFrustumOrigin, const Vector3 & vFrustumRotation, float fHorizontalLength, float fVerticalLength, float fNearPlane, float fFarPlane)
{
	return IntersectFrustumOrientedBox(vLT, vRB, Vector3::Zero, vFrustumOrigin, vFrustumRotation, fHorizontalLength, fVerticalLength, fNearPlane, fFarPlane);
}

int CPhysics::IntersectFrustumOrientedBox(const Vector3 & vLT, const Vector3 & vRB, const Vector3 & vRotation, const Vector3 & vFrustumOrigin, const Vector3 & vFrustumRotation, float fHorizontalLength, float fVerticalLength, float fNearPlane, float fFarPlane)
{
	static const XMVECTORI32 SelectY =
	{
		XM_SELECT_0, XM_SELECT_1, XM_SELECT_0, XM_SELECT_0
	};
	static const XMVECTORI32 SelectZ =
	{
		XM_SELECT_0, XM_SELECT_0, XM_SELECT_1, XM_SELECT_0
	};



	float fRightSlope = (fHorizontalLength / 2.0f) / fFarPlane;
	float fLeftSlope = fRightSlope;
	float fTopSlope = (fVerticalLength / 2.0f) / fFarPlane;
	float fBottomSlope = fTopSlope;

	XMVECTOR Zero = XMVectorZero();

	// Build the frustum planes.
	XMVECTOR Planes[6];
	Planes[0] = XMVectorSet(0.0f, 0.0f, -1.0f, fNearPlane);
	Planes[1] = XMVectorSet(0.0f, 0.0f, 1.0f, -fFarPlane);
	Planes[2] = XMVectorSet(1.0f, 0.0f, -fRightSlope, 0.0f);
	Planes[3] = XMVectorSet(-1.0f, 0.0f, fLeftSlope, 0.0f);
	Planes[4] = XMVectorSet(0.0f, 1.0f, -fTopSlope, 0.0f);
	Planes[5] = XMVectorSet(0.0f, -1.0f, fBottomSlope, 0.0f);

	// Load origin and orientation of the frustum.
	XMVECTOR Origin = vFrustumOrigin.Convert();
	XMVECTOR FrustumOrientation = Vector3::ToQuaternion(vFrustumRotation);
	XMQuaternionNormalize(FrustumOrientation);

	// Load the box.
	XMVECTOR Center = (vLT - vRB) / 2.0f;
	XMVECTOR Extents = (vLT - vRB).Abs();
	XMVECTOR BoxOrientation = Vector3::ToQuaternion(vRotation);
	XMQuaternionNormalize(BoxOrientation);

	// Transform the oriented box into the space of the frustum in order to 
	// minimize the number of transforms we have to do.
	Center = XMVector3InverseRotate(Center - Origin, FrustumOrientation);
	BoxOrientation = XMQuaternionMultiply(BoxOrientation, XMQuaternionConjugate(FrustumOrientation));

	// Set w of the center to one so we can dot4 with the plane.
	Center = XMVectorInsert(Center, XMVectorSplatOne(), 0, 0, 0, 0, 1);

	// Build the 3x3 rotation matrix that defines the box axes.
	XMMATRIX R = XMMatrixRotationQuaternion(BoxOrientation);

	// Check against each plane of the frustum.
	XMVECTOR Outside = XMVectorFalseInt();
	XMVECTOR InsideAll = XMVectorTrueInt();
	XMVECTOR CenterInsideAll = XMVectorTrueInt();

	for (INT i = 0; i < 6; i++)
	{
		// Compute the distance to the center of the box.
		XMVECTOR Dist = XMVector4Dot(Center, Planes[i]);

		// Project the axes of the box onto the normal of the plane.  Half the
		// length of the projection (sometime called the "radius") is equal to
		// h(u) * abs(n dot b(u))) + h(v) * abs(n dot b(v)) + h(w) * abs(n dot b(w))
		// where h(i) are extents of the box, n is the plane normal, and b(i) are the 
		// axes of the box.
		XMVECTOR Radius = XMVector3Dot(Planes[i], R.r[0]);
		Radius = XMVectorSelect(Radius, XMVector3Dot(Planes[i], R.r[1]), SelectY);
		Radius = XMVectorSelect(Radius, XMVector3Dot(Planes[i], R.r[2]), SelectZ);
		Radius = XMVector3Dot(Extents, XMVectorAbs(Radius));

		// Outside the plane?
		Outside = XMVectorOrInt(Outside, XMVectorGreater(Dist, Radius));

		// Fully inside the plane?
		InsideAll = XMVectorAndInt(InsideAll, XMVectorLessOrEqual(Dist, -Radius));

		// Check if the center is inside the plane.
		CenterInsideAll = XMVectorAndInt(CenterInsideAll, XMVectorLessOrEqual(Dist, Zero));
	}

	// If the box is outside any of the planes it is outside. 
	if (XMVector4EqualInt(Outside, XMVectorTrueInt()))
		return 0;

	// If the box is inside all planes it is fully inside.
	if (XMVector4EqualInt(InsideAll, XMVectorTrueInt()))
		return 2;

	// If the center of the box is inside all planes and the box intersects 
	// one or more planes then it must intersect.
	if (XMVector4EqualInt(CenterInsideAll, XMVectorTrueInt()))
		return 1;

	// Build the corners of the frustum.
	XMVECTOR RightTop = XMVectorSet(fRightSlope, fTopSlope, 1.0f, 0.0f);
	XMVECTOR RightBottom = XMVectorSet(fRightSlope, fBottomSlope, 1.0f, 0.0f);
	XMVECTOR LeftTop = XMVectorSet(fLeftSlope, fTopSlope, 1.0f, 0.0f);
	XMVECTOR LeftBottom = XMVectorSet(fLeftSlope, fBottomSlope, 1.0f, 0.0f);
	XMVECTOR Near = XMVectorReplicate(fNearPlane);
	XMVECTOR Far = XMVectorReplicate(fFarPlane);

	XMVECTOR Corners[8];
	Corners[0] = RightTop * Near;
	Corners[1] = RightBottom * Near;
	Corners[2] = LeftTop * Near;
	Corners[3] = LeftBottom * Near;
	Corners[4] = RightTop * Far;
	Corners[5] = RightBottom * Far;
	Corners[6] = LeftTop * Far;
	Corners[7] = LeftBottom * Far;

	// Test against box axes (3)
	{
		// Find the min/max values of the projection of the frustum onto each axis.
		XMVECTOR FrustumMin, FrustumMax;

		FrustumMin = XMVector3Dot(Corners[0], R.r[0]);
		FrustumMin = XMVectorSelect(FrustumMin, XMVector3Dot(Corners[0], R.r[1]), SelectY);
		FrustumMin = XMVectorSelect(FrustumMin, XMVector3Dot(Corners[0], R.r[2]), SelectZ);
		FrustumMax = FrustumMin;

		for (INT i = 1; i < 8; i++)
		{
			XMVECTOR Temp = XMVector3Dot(Corners[i], R.r[0]);
			Temp = XMVectorSelect(Temp, XMVector3Dot(Corners[i], R.r[1]), SelectY);
			Temp = XMVectorSelect(Temp, XMVector3Dot(Corners[i], R.r[2]), SelectZ);

			FrustumMin = XMVectorMin(FrustumMin, Temp);
			FrustumMax = XMVectorMax(FrustumMax, Temp);
		}

		// Project the center of the box onto the axes.
		XMVECTOR BoxDist = XMVector3Dot(Center, R.r[0]);
		BoxDist = XMVectorSelect(BoxDist, XMVector3Dot(Center, R.r[1]), SelectY);
		BoxDist = XMVectorSelect(BoxDist, XMVector3Dot(Center, R.r[2]), SelectZ);

		// The projection of the box onto the axis is just its Center and Extents.
		// if (min > box_max || max < box_min) reject;
		XMVECTOR Result = XMVectorOrInt(XMVectorGreater(FrustumMin, BoxDist + Extents),
			XMVectorLess(FrustumMax, BoxDist - Extents));

		if (XMVector3AnyTrue(Result))
			return 0;
	}

	// Test against edge/edge axes (3*6).
	XMVECTOR FrustumEdgeAxis[6];

	FrustumEdgeAxis[0] = RightTop;
	FrustumEdgeAxis[1] = RightBottom;
	FrustumEdgeAxis[2] = LeftTop;
	FrustumEdgeAxis[3] = LeftBottom;
	FrustumEdgeAxis[4] = RightTop - LeftTop;
	FrustumEdgeAxis[5] = LeftBottom - LeftTop;

	for (INT i = 0; i < 3; i++)
	{
		for (INT j = 0; j < 6; j++)
		{
			// Compute the axis we are going to test.
			XMVECTOR Axis = XMVector3Cross(R.r[i], FrustumEdgeAxis[j]);

			// Find the min/max values of the projection of the frustum onto the axis.
			XMVECTOR FrustumMin, FrustumMax;

			FrustumMin = FrustumMax = XMVector3Dot(Axis, Corners[0]);

			for (INT k = 1; k < 8; k++)
			{
				XMVECTOR Temp = XMVector3Dot(Axis, Corners[k]);
				FrustumMin = XMVectorMin(FrustumMin, Temp);
				FrustumMax = XMVectorMax(FrustumMax, Temp);
			}

			// Project the center of the box onto the axis.
			XMVECTOR Dist = XMVector3Dot(Center, Axis);

			// Project the axes of the box onto the axis to find the "radius" of the box.
			XMVECTOR Radius = XMVector3Dot(Axis, R.r[0]);
			Radius = XMVectorSelect(Radius, XMVector3Dot(Axis, R.r[1]), SelectY);
			Radius = XMVectorSelect(Radius, XMVector3Dot(Axis, R.r[2]), SelectZ);
			Radius = XMVector3Dot(Extents, XMVectorAbs(Radius));

			// if (center > max + radius || center < min - radius) reject;
			Outside = XMVectorOrInt(Outside, XMVectorGreater(Dist, FrustumMax + Radius));
			Outside = XMVectorOrInt(Outside, XMVectorLess(Dist, FrustumMin - Radius));
		}
	}

	if (XMVector4EqualInt(Outside, XMVectorTrueInt()))
		return 0;

	// If we did not find a separating plane then the box must intersect the frustum.
	return 1;
}


XMVECTOR CPhysics::PointOnLineSegmentNearestPoint(FXMVECTOR S1, FXMVECTOR S2, FXMVECTOR P)
{	
	XMVECTOR Dir = S2 - S1;
	XMVECTOR Projection = (XMVector3Dot(P, Dir) - XMVector3Dot(S1, Dir));
	XMVECTOR LengthSq = XMVector3Dot(Dir, Dir);

	XMVECTOR t = Projection * XMVectorReciprocal(LengthSq);
	XMVECTOR Point = S1 + t * Dir;

	// t < 0
	XMVECTOR SelectS1 = XMVectorLess(Projection, XMVectorZero());
	Point = XMVectorSelect(Point, S1, SelectS1);

	// t > 1
	XMVECTOR SelectS2 = XMVectorGreater(Projection, LengthSq);
	Point = XMVectorSelect(Point, S2, SelectS2);

	return Point;
}

bool CPhysics::Initialize()
{
	return true;
}
