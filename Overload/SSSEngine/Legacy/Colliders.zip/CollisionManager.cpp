#include "CollisionManager.h"
#include "Core.h"
#include "Layer.h"
#include "Scene.h"
#include "SceneManager.h"
#include "Component\UICollider.h"
#include "Collider.h"
#include "CollisionVoxel2D.h"
#include "CollisionVoxel3D.h"
#include "GameObject.h"
#include "Input.h"
#include "Physics.h"
#include "Component\Camera.h"

#include "Device.h"

#include "Transform.h"
#include "Debug.h"


SSS_USING

DEFINITION_SINGLE(CCollisionManager)

CCollisionManager::CCollisionManager() :
	m_vVoxelSize2D(Vector2(256.0f, 256.0f)),
	m_vVoxelSize3D(Vector3(32.0f, 32.0f, 32.0f)),
	m_pCoveredButtonCollider(NULL),
	m_pCoveredCollider(NULL),
	m_fFixedTimeStep(1.0f / 60.0f),
	m_fCullingDistance(1000.0f),
	m_vGravity(0.0f, -9.81f, 0.0f)
{
	m_pFoundation = NULL;
	m_pPhysics = NULL;
	m_pDispatcher = NULL;
	m_pScene = NULL;
	m_pMaterial = NULL;
	m_pPvd = NULL;
	
}


CCollisionManager::~CCollisionManager()
{
	if (m_pScene)
	{
		//Scene�� �浹ü���� ������.
		m_pScene->flushSimulation();
		//Scene ������
		m_pScene->release();
	}
	if(m_pDispatcher)
		m_pDispatcher->release();
	
	if(m_pPhysics)
		m_pPhysics->release();
	
	if (m_pPvd)
	{
		PxPvdTransport* transport = m_pPvd->getTransport();
		m_pPvd->release();
		transport->release();
	}

	if(m_pFoundation)
		m_pFoundation->release();

	{
		unordered_map<Vector2, CCollisionVoxel2D*>::iterator iter;
		unordered_map<Vector2, CCollisionVoxel2D*>::iterator iterEnd = m_mapCollisionVoxel2D.end();
		for (iter = m_mapCollisionVoxel2D.begin(); iter != iterEnd; ++iter)
		{
			SAFE_DELETE(iter->second);
		}
		m_mapCollisionVoxel2D.clear();
	}


	{
		unordered_map<Vector3, CCollisionVoxel3D*>::iterator iter;
		unordered_map<Vector3, CCollisionVoxel3D*>::iterator iterEnd = m_mapCollisionVoxel3D.end();
		for (iter = m_mapCollisionVoxel3D.begin(); iter != iterEnd; ++iter)
		{
			SAFE_DELETE(iter->second);
		}
		m_mapCollisionVoxel3D.clear();
	}

}

PxPhysics * CCollisionManager::GetPhysics() const
{
	if (m_pPhysics)
	{
		return m_pPhysics;
	}

	return NULL;
}

void CCollisionManager::AddCollider(CCollider * pCollider)
{
	if (pCollider)
	{
		m_pScene->addActor(*pCollider->m_pActor);
	}
}

void CCollisionManager::SetGravity(const Vector3 & vGravity)
{
	m_vGravity = vGravity;
	m_pScene->setGravity(PxVec3(m_vGravity.x, m_vGravity.y, m_vGravity.z));
}

Vector3 CCollisionManager::GetGravity() const
{
	return m_vGravity;
}

float CCollisionManager::GetCullingDistance() const
{
	return m_fCullingDistance;
}

void CCollisionManager::SetCullingDistance(float fDistance)
{
	m_fCullingDistance = fDistance;
}

float CCollisionManager::GetFixedTimeStep() const
{
	return m_fFixedTimeStep;
}

void CCollisionManager::SetFixedTimeStep(float fTimeStep)
{
	m_fFixedTimeStep = fTimeStep;
}

void CCollisionManager::Reset()
{
	{
		unordered_map<Vector2, CCollisionVoxel2D*>::iterator iter;
		unordered_map<Vector2, CCollisionVoxel2D*>::iterator iterEnd = m_mapCollisionVoxel2D.end();
		for (iter = m_mapCollisionVoxel2D.begin(); iter != iterEnd; ++iter)
		{
			SAFE_DELETE(iter->second);
		}
		m_mapCollisionVoxel2D.clear();
	}


	{
		unordered_map<Vector3, CCollisionVoxel3D*>::iterator iter;
		unordered_map<Vector3, CCollisionVoxel3D*>::iterator iterEnd = m_mapCollisionVoxel3D.end();
		for (iter = m_mapCollisionVoxel3D.begin(); iter != iterEnd; ++iter)
		{
			SAFE_DELETE(iter->second);
		}
		m_mapCollisionVoxel3D.clear();
	}

}

PxRigidDynamic * CCollisionManager::CreateDynamic(const PxTransform & t, const PxGeometry & geometry, const PxVec3 & velocity)
{	
	PxRigidDynamic* dynamic = PxCreateDynamic(*m_pPhysics, t, geometry, *m_pMaterial, 10.0f);
	dynamic->setAngularDamping(0.5f);
	dynamic->setLinearVelocity(velocity);
	m_pScene->addActor(*dynamic);
	return dynamic;
}

void CCollisionManager::CreateStack(const PxTransform & t, PxU32 size, PxReal halfExtent)
{


	PxShape* shape = m_pPhysics->createShape(PxBoxGeometry(halfExtent, halfExtent, halfExtent), *m_pMaterial);
	
	
	PxRigidDynamic* Box = PxCreateKinematic(*m_pPhysics, t, *shape, PxReal(800.0f));
	PxRigidBodyExt::updateMassAndInertia(*Box, 10.0f);
	m_pScene->addActor(*Box);
	//for (PxU32 i = 0; i<size; i++)
	//{
	//	for (PxU32 j = 0; j<size - i; j++)
	//	{
	//		PxTransform localTm(PxVec3(PxReal(j * 2) - PxReal(size - i), PxReal(i * 2 + 1), 0) * halfExtent);
	//		PxRigidDynamic* body = m_pPhysics->createRigidDynamic(t.transform(localTm));
	//		body->
	//		body->attachShape(*shape);
	//		PxRigidBodyExt::updateMassAndInertia(*body, 10.0f);
	//		m_pScene->addActor(*body);
	//	}
	//}
	shape->release();

}

void CCollisionManager::CleanupPhysics(bool interactive)
{
	PX_UNUSED(interactive);
	m_pScene->release();
	m_pDispatcher->release();
	m_pPhysics->release();
	PxPvdTransport* transport = m_pPvd->getTransport();
	m_pPvd->release();
	transport->release();
	
	m_pFoundation->release();
}


Vector2 CCollisionManager::GetVoxelSize2D() const
{
	return m_vVoxelSize2D;
}

Vector3 CCollisionManager::GetVoxelSize3D() const
{
	return m_vVoxelSize3D;
}

const unordered_map<Vector2, class CCollisionVoxel2D*>& CCollisionManager::GetVoxel2D() const
{
	return m_mapCollisionVoxel2D;
}

const unordered_map<Vector3, class CCollisionVoxel3D*>& CCollisionManager::GetVoxel3D() const
{
	return m_mapCollisionVoxel3D;
}

CCollisionVoxel2D * CCollisionManager::GetVoxel2D(const Vector2 & position)
{
	unordered_map<Vector2, CCollisionVoxel2D*>::const_iterator iter = m_mapCollisionVoxel2D.find(position);

	if (iter == m_mapCollisionVoxel2D.end())
	{
		return CreateVoxel(position);
	}

	return iter->second;
}

CCollisionVoxel2D * CCollisionManager::GetVoxel2D(const Vector3 & position) 
{
	unordered_map<Vector2, CCollisionVoxel2D*>::const_iterator iter = m_mapCollisionVoxel2D.find(Vector2(position.x, position.y));

	if (iter == m_mapCollisionVoxel2D.end())
	{
		return CreateVoxel(Vector2(position.x , position.y));
	}

	return iter->second;
}

CCollisionVoxel2D * CCollisionManager::GetVoxel2D(float x, float y)
{
	unordered_map<Vector2, CCollisionVoxel2D*>::const_iterator iter = m_mapCollisionVoxel2D.find(Vector2(x, y));

	if (iter == m_mapCollisionVoxel2D.end())
	{
		return CreateVoxel(Vector2(x, y));
	}

	return iter->second;
}

CCollisionVoxel3D * CCollisionManager::GetVoxel3D(const Vector3 & position) 
{
	unordered_map<Vector3, CCollisionVoxel3D*>::const_iterator iter = m_mapCollisionVoxel3D.find(position);

	if (iter == m_mapCollisionVoxel3D.end())
	{
		return NULL;
		//return CreateVoxel(position);
	}

	return iter->second;
}

CCollisionVoxel3D * CCollisionManager::GetVoxel3D(float x, float y, float z) 
{
	unordered_map<Vector3, CCollisionVoxel3D*>::const_iterator iter = m_mapCollisionVoxel3D.find(Vector3(x, y, z));

	if (iter == m_mapCollisionVoxel3D.end())
	{
		return CreateVoxel(Vector3(x, y, z));
	}

	return iter->second;
}

void CCollisionManager::ClearCoveredUI()
{
	m_pCoveredButtonCollider = NULL;
}

void CCollisionManager::ClearCoveredCollider()
{
	m_pCoveredCollider = NULL;
}

CUICollider * CCollisionManager::GetCoveredUI() const
{
	return m_pCoveredButtonCollider;
}

CCollider * CCollisionManager::GetCoveredCollider() const
{
	return m_pCoveredCollider;
}

size_t CCollisionManager::GetVoxel2DCount() const
{
	return m_mapCollisionVoxel2D.size();
}

size_t CCollisionManager::GetVoxel3DCount() const
{
	return m_mapCollisionVoxel3D.size();
}

void CCollisionManager::SetVoxelSize2D(const Vector2 & vSize)
{
	m_vVoxelSize2D = vSize;
}

void CCollisionManager::SetVoxelSize2D(float fWidth, float fHeight)
{
	m_vVoxelSize2D.x = fWidth;
	m_vVoxelSize2D.y = fHeight;
}

void CCollisionManager::SetVoxelSize3D(const Vector3 & vSize)
{
	m_vVoxelSize3D = vSize;	
}

void CCollisionManager::SetVoxelSize3D(float x, float y, float z)
{
	m_vVoxelSize3D.x = x;
	m_vVoxelSize3D.y = y;
	m_vVoxelSize3D.z = z;
}

void CCollisionManager::RemoveVoxel2D(const Vector2 & vKeyPosition)
{
	unordered_map<Vector2, CCollisionVoxel2D*>::iterator iter = m_mapCollisionVoxel2D.find(vKeyPosition);
	if (iter == m_mapCollisionVoxel2D.end())
		return;

	delete iter->second;
	m_mapCollisionVoxel2D.erase(iter);

}

void CCollisionManager::RemoveVoxel2D(float fKeyX, float fKeyY)
{
	unordered_map<Vector2, CCollisionVoxel2D*>::iterator iter = m_mapCollisionVoxel2D.find(Vector2(fKeyX, fKeyY));
	if (iter == m_mapCollisionVoxel2D.end())
		return;

	delete iter->second;
	m_mapCollisionVoxel2D.erase(iter);

}

void CCollisionManager::RemoveVoxel2D(CCollisionVoxel2D * pTarget)
{
}

void CCollisionManager::RemoveVoxel3D(const Vector3 & vKeyPosition)
{
	unordered_map<Vector3, CCollisionVoxel3D*>::iterator iter = m_mapCollisionVoxel3D.find(vKeyPosition);
	if (iter == m_mapCollisionVoxel3D.end())
		return;

	delete iter->second;
	m_mapCollisionVoxel3D.erase(iter);

}

void CCollisionManager::RemoveVoxel3D(float fKeyX, float fKeyY, float fKeyZ)
{
	unordered_map<Vector3, CCollisionVoxel3D*>::iterator iter = m_mapCollisionVoxel3D.find(Vector3(fKeyX, fKeyY, fKeyZ));
	if (iter == m_mapCollisionVoxel3D.end())
		return;

	delete iter->second;
	m_mapCollisionVoxel3D.erase(iter);

}

CCollisionVoxel2D * CCollisionManager::CreateEmptyVoxel(const Vector2 & vKeyPosition)
{
	unordered_map<Vector2, CCollisionVoxel2D*>::iterator iter = m_mapCollisionVoxel2D.find(vKeyPosition);
	if (iter == m_mapCollisionVoxel2D.end())
	{
		return iter->second;
	}
	else
	{
		CCollisionVoxel2D* pVoxel = new CCollisionVoxel2D;
		pVoxel->SetKeyPosition(vKeyPosition);
		m_mapCollisionVoxel2D.insert(make_pair(vKeyPosition, pVoxel));
	}
}

CCollisionVoxel3D * CCollisionManager::CreateEmptyVoxel(const Vector3 & vKeyPosition)
{
	unordered_map<Vector3, CCollisionVoxel3D*>::iterator iter = m_mapCollisionVoxel3D.find(vKeyPosition);
	if (iter == m_mapCollisionVoxel3D.end())
	{
		CCollisionVoxel3D* pVoxel = new CCollisionVoxel3D;
		pVoxel->SetKeyPosition(vKeyPosition);
		m_mapCollisionVoxel3D.insert(make_pair(vKeyPosition, pVoxel));
		return pVoxel;
	}
	else
	{
		return iter->second;
	}
}


CCollisionVoxel3D* CCollisionManager::CreateVoxel(const Vector3& vKeyPosition)
{
	CCollisionVoxel3D* pVoxel;

	pVoxel = new CCollisionVoxel3D;
	m_mapCollisionVoxel3D.insert(make_pair(vKeyPosition, pVoxel));

	return pVoxel;
}

CCollisionVoxel2D* CCollisionManager::CreateVoxel(const Vector2& vKeyPosition)
{
	CCollisionVoxel2D* pVoxel;

	pVoxel = new CCollisionVoxel2D;
	pVoxel->SetKeyPosition(vKeyPosition);
	m_mapCollisionVoxel2D.insert(make_pair(vKeyPosition, pVoxel));

	return pVoxel;
}

void CCollisionManager::ClearVoxel2D()
{
	unordered_map<Vector2, CCollisionVoxel2D*>::iterator iter;
	unordered_map<Vector2, CCollisionVoxel2D*>::iterator iterEnd = m_mapCollisionVoxel2D.end();
	for (iter = m_mapCollisionVoxel2D.begin(); iter != iterEnd; ++iter)
	{
		SAFE_DELETE(iter->second);
	}
	m_mapCollisionVoxel2D.clear();
}

void CCollisionManager::ClearVoxel3D()
{
	unordered_map<Vector3, CCollisionVoxel3D*>::iterator iter;
	unordered_map<Vector3, CCollisionVoxel3D*>::iterator iterEnd = m_mapCollisionVoxel3D.end();
	for (iter = m_mapCollisionVoxel3D.begin(); iter != iterEnd; ++iter)
	{
		SAFE_DELETE(iter->second);
	}
	m_mapCollisionVoxel3D.clear();
}

bool CCollisionManager::Initialize()
{
	bool bInteractive = false;
	char* strCallBackIP = "127.0.0.1";
	
	//PhysX Init
	
	m_pFoundation = PxCreateFoundation(PX_FOUNDATION_VERSION, m_Allocator, m_ErrorCallback);
	
	m_pPvd = PxCreatePvd(*m_pFoundation);
	PxPvdTransport* transport = PxDefaultPvdSocketTransportCreate(strCallBackIP, 5425, 10);
	bool bPVDConnectionResult = m_pPvd->connect(*transport, PxPvdInstrumentationFlag::eALL);
	if (!bPVDConnectionResult)
	{
		GET_SINGLE(CDebug)->Log(L"CCollisionManager::Initialize() ���� PVD ���ῡ �����߽��ϴ�. PVD�� �����ִ��� Ȯ�����ּ���.\n");
		GET_SINGLE(CDebug)->Log(L"PVD�� ������� ������� �����ص� �˴ϴ�.\n");
	}
	
	m_pPhysics = PxCreatePhysics(PX_PHYSICS_VERSION, *m_pFoundation, PxTolerancesScale(), true, m_pPvd);
	
	PxSceneDesc sceneDesc(m_pPhysics->getTolerancesScale());
	sceneDesc.gravity = PxVec3(m_vGravity.x, m_vGravity.y, m_vGravity.z);
	m_pDispatcher = PxDefaultCpuDispatcherCreate(2);
	sceneDesc.cpuDispatcher = m_pDispatcher;
	sceneDesc.filterShader = PxDefaultSimulationFilterShader;
	m_pScene = m_pPhysics->createScene(sceneDesc);
	
	PxPvdSceneClient* pvdClient = m_pScene->getScenePvdClient();
	if (pvdClient)
	{
		pvdClient->setScenePvdFlag(PxPvdSceneFlag::eTRANSMIT_CONSTRAINTS, true);
		pvdClient->setScenePvdFlag(PxPvdSceneFlag::eTRANSMIT_CONTACTS, true);
		pvdClient->setScenePvdFlag(PxPvdSceneFlag::eTRANSMIT_SCENEQUERIES, true);
	}
	m_pMaterial = m_pPhysics->createMaterial(1.0f, 0.8f, 0.0f);
	
	PxRigidStatic* groundPlane = PxCreatePlane(*m_pPhysics, PxPlane(0, 1, 0, 0), *m_pMaterial);
	m_pScene->addActor(*groundPlane);
	
	float stackZ = 10.0f;
	
	for (PxU32 i = 0; i < 5; i++)
	{
		CreateStack(PxTransform(PxVec3(0, 0, stackZ -= 10.0f)), 10, 2.0f);		
	}
	
	//if (!bInteractive)
	//	CreateDynamic(PxTransform(PxVec3(0, 40, 100)), PxSphereGeometry(10), PxVec3(0, -50, -100));

	return true;
}

int CCollisionManager::UpdateCollision(float fTime)
{
	m_pScene->simulate(fTime);
	m_pScene->fetchResults(true);


	CScene* pScene = GET_SINGLE(CSceneManager)->GetCurrentScene();

	Vector2 vCursorPosition = GET_SINGLE(CInput)->GetCursorPosition(SPACE_DEVICE);
	bool bCollisionWithUI = false;
	bool bCursorDown = GETKEYDOWN(VK_LBUTTON) || GETKEYDOWN(VK_RBUTTON);
	bool bCursorPressed = GETKEY(VK_LBUTTON) || GETKEY(VK_RBUTTON);
	bool bCursorUp = GETKEYUP(VK_LBUTTON) || GETKEYUP(VK_RBUTTON);
		

#pragma region UI Collision
	{
		list<CUICollider*>::const_iterator iter;
		list<CUICollider*>::const_iterator iterEnd = pScene->GetButtonColliderList()->end();

		for (iter = pScene->GetButtonColliderList()->begin(); iter != iterEnd; ++iter)
		{
			CGameObject* pButton = (*iter)->GetGameObject();
			bool bEnable = pButton->IsEnable();
			SAFE_RELEASE(pButton);

			if ((*iter)->IsEnable() && bEnable)
			{
				bool bPrevCollision = (*iter)->GetCollision();
				bool bCurrentCollision = (*iter)->CheckCollision(vCursorPosition);

				if (!bPrevCollision && bCurrentCollision)
				{
					bCollisionWithUI = true;

					if (m_pCoveredButtonCollider)
					{						
						CGameObject* pCoveredButton = m_pCoveredButtonCollider->GetGameObject();
						pCoveredButton->OnMouseExit(NULL, vCursorPosition, Vector3::Zero);
						m_pCoveredButtonCollider->SetCollision(false);
						SAFE_RELEASE(pCoveredButton);

						CGameObject* pTargetButton = (*iter)->GetGameObject();
						pTargetButton->OnMouseEnter(NULL, vCursorPosition, Vector3::Zero);
						(*iter)->SetCollision(true);
						m_pCoveredButtonCollider = (*iter);
						SAFE_RELEASE(pTargetButton);
					}
					else
					{
						CGameObject* pTargetButton = (*iter)->GetGameObject();
						pTargetButton->OnMouseEnter(NULL, vCursorPosition, Vector3::Zero);
						(*iter)->SetCollision(true);
						m_pCoveredButtonCollider = (*iter);
						SAFE_RELEASE(pTargetButton);
					}
				}
				else if (bPrevCollision && bCurrentCollision)
				{
					bCollisionWithUI = true;

					CGameObject* pTargetButton = (*iter)->GetGameObject();
					pTargetButton->OnMouseStay(NULL, vCursorPosition, Vector3::Zero, fTime);
					SAFE_RELEASE(pTargetButton);
				}
				else if (bPrevCollision && !bCurrentCollision)
				{
					bCollisionWithUI = true;

					CGameObject* pTargetButton = (*iter)->GetGameObject();
					pTargetButton->OnMouseExit(NULL, vCursorPosition, Vector3::Zero);
					(*iter)->SetCollision(false);
					m_pCoveredButtonCollider = NULL;
					SAFE_RELEASE(pTargetButton);
				}
				else
				{
					continue;
				}
			}
		}
	}
#pragma endregion

	CTransform* pCameraTransform = pScene->GetMainCameraTransform();
	Vector3 vCameraPosition = pCameraTransform->GetWorldPosition();
	SAFE_RELEASE(pCameraTransform);

#pragma region Clear Phase
	{
		//���̾ ���鼭, �� Collider�� �ڽ��� ���ԵǴ� Voxel�� ������Ʈ ��.
		//Voxel�� Collider ���ο��� ���� ���� �����, ���Ҵ� �Ѵ�.

		CScene* pScene = GET_SINGLE(CSceneManager)->GetCurrentScene();

		list<CCollider*>::const_iterator iter;
		list<CCollider*>::const_iterator iterEnd = pScene->GetColliderList()->end();

		for (iter = pScene->GetColliderList()->begin(); iter != iterEnd; ++iter)
		{
			(*iter)->SetCollisionVoxel();
		}

		SAFE_RELEASE(pScene);
	}
#pragma endregion
//
//#pragma region 2D
//	{
//		unordered_map<Vector2, CCollisionVoxel2D*>::iterator iter;
//		unordered_map<Vector2, CCollisionVoxel2D*>::iterator iterEnd = m_mapCollisionVoxel2D.end();
//
//		for (iter = m_mapCollisionVoxel2D.begin(); iter != iterEnd;)
//		{
//			size_t iCount = (*iter).second->GetContainedColliderCount();
//
//			if (iCount == 0)
//			{
//				delete (*iter).second;
//				iter = m_mapCollisionVoxel2D.erase(iter);
//				continue;
//			}
//			//else if (iCount < 2)
//			//{				
//			//	unordered_map<CCollider*, CCollider*>::const_iterator iterTemp = (*iter).second->m_mapContainedCollider.begin();
//			//	size_t iCollisionCount = iterTemp->second->m_mapCollision.size();
//			//	
//			//	//Ÿ���� ������Ʈ�� 1���� ��, ������ �浹�� ������Ʈ�� 1�� �̻��̸�
//			//	//������ �浹�� ������Ʈ�� Exit ó���ϵ��� �Ѵ�.
//			//	if (iCollisionCount > 0)
//			//	{
//			//		CGameObject* pGameObjectA = iterTemp->second->GetGameObject();
//			//		CCollider* pColliderA = iterTemp->second;
//			//	
//			//		unordered_map<CCollider*, CCollider*>::const_iterator iterTarget = iterTemp->second->m_mapCollision.begin();
//			//		unordered_map	<CCollider*, CCollider*>::const_iterator iterTargetEnd = iterTemp->second->m_mapCollision.end();
//			//	
//			//		for (; iterTarget != iterTargetEnd; )
//			//		{
//			//			CGameObject* pGameObjectB = iterTarget->second->GetGameObject();
//			//			CCollider* pColliderB = iterTarget->second;
//			//	
//			//			pGameObjectA->OnCollisionExit(pColliderB, fTime);
//			//			pGameObjectB->OnCollisionExit(pColliderA, fTime);
//			//	
//			//			iterTarget = pColliderA->m_mapCollision.erase(iterTarget);
//			//			pColliderB->m_mapCollision.erase(pColliderB->m_mapCollision.find(pColliderA));
//			//			iterTargetEnd = pColliderA->m_mapCollision.end();
//			//	
//			//			SAFE_RELEASE(pGameObjectB);
//			//		}
//			//		SAFE_RELEASE(pGameObjectA);
//			//	}
//			//
//			//	++iter;
//			//	continue;
//			//}
//			else
//			{
//				//�� �浹ü���� �浹�ϰ�, �Լ� ȣ�� ����
//				unordered_map<CCollider*, CCollider*>::iterator iterA = (*iter).second->GetContainedColliders()->begin();
//				unordered_map<CCollider*, CCollider*>::iterator iterB = (*iter).second->GetContainedColliders()->begin();
//				unordered_map<CCollider*, CCollider*>::iterator iterAEnd = (*iter).second->GetContainedColliders()->end();
//				unordered_map<CCollider*, CCollider*>::iterator iterBEnd = (*iter).second->GetContainedColliders()->end();
//
//				--iterAEnd;
//				//O(n * (n / 2))s
//				for (; iterA != iterAEnd; ++iterA)
//				{
//					iterB = ++iterA;
//					--iterA;
//					for (; iterB != iterBEnd; ++iterB)
//					{
//						CCollider* pColliderA = (*iterA).second;
//						CCollider* pColliderB = (*iterB).second;
//
//						if (!pColliderA || !pColliderB)
//						{
//							continue;
//						}
//
//						CGameObject* pGameObjectA = pColliderA->GetGameObject();
//						CGameObject* pGameObjectB = pColliderB->GetGameObject();
//
//						CLayer* pLayerA = pGameObjectA->GetLayer();
//						CLayer* pLayerB = pGameObjectB->GetLayer();
//
//						if (pGameObjectA != pGameObjectB)
//						{
//							if (pScene->GetLayerCollision(pLayerA, pLayerB))
//							{
//								bool isCollide = pColliderA->CollisionCheck(pColliderB);
//								bool wasCollided = pColliderA->ContainCollision(pColliderB);
//
//								if (isCollide && !wasCollided)
//								{
//									pGameObjectA->OnCollisionEnter(pColliderA, pColliderB, fTime);
//									pGameObjectB->OnCollisionEnter(pColliderB, pColliderA, fTime);
//
//									pColliderA->AddCollisionList(pColliderB);
//									pColliderB->AddCollisionList(pColliderA);
//								}
//								else if (isCollide && wasCollided)
//								{
//									pGameObjectA->OnCollisionStay(pColliderA, pColliderB, fTime);
//									pGameObjectB->OnCollisionStay(pColliderB, pColliderA, fTime);
//
//									pColliderA->AddCollisionList(pColliderB);
//									pColliderB->AddCollisionList(pColliderA);
//								}
//								else if (!isCollide && wasCollided)
//								{
//									pGameObjectA->OnCollisionExit(pColliderA, pColliderB, fTime);
//									pGameObjectB->OnCollisionExit(pColliderB, pColliderA, fTime);
//
//									pColliderA->RemoveTargetFromCollisionList(pColliderB);
//									pColliderB->RemoveTargetFromCollisionList(pColliderA);
//								}
//							}
//						}
//
//						SAFE_RELEASE(pLayerA);
//						SAFE_RELEASE(pLayerB);
//						SAFE_RELEASE(pGameObjectA);
//						SAFE_RELEASE(pGameObjectB);
//					}
//				}
//				++iter;
//			}
//		}
//	}
//#pragma endregion
//
//	

#pragma region Ray Picking
{
	if (!bCollisionWithUI)
	{
		CCamera* pCamera = pScene->GetMainCamera();
		CTransform* pCameraTransform = pCamera->GetTransform();
		//Vector3 vCameraPosition = pCameraTransform->GetWorldPosition();
		RAY tRay = pCamera->ScreenPointToRay(vCursorPosition);

		if (vCursorPosition.x > 0 && vCursorPosition.x < DEVICE_RESOLUTION.iWidth && vCursorPosition.y > 0 &&
			vCursorPosition.y < DEVICE_RESOLUTION.iHeight)
		{
			Vector3 vIntersectPosition;
			CCollider* pCollideTarget = NULL;

			pCollideTarget = GET_SINGLE(CPhysics)->RayCast(tRay, &vIntersectPosition);

			if (pCollideTarget)
			{
				CGameObject* pTargetObject = pCollideTarget->GetGameObject();
				bool bEnable = pTargetObject->IsEnable();

				if (bEnable && pCollideTarget->IsEnable())
				{
					if (m_pCoveredCollider == pCollideTarget)
					{
						pTargetObject->OnMouseStay(pCollideTarget, vCursorPosition, vIntersectPosition, fTime);

						if (bCursorDown)
						{
							pTargetObject->OnMouseDown(pCollideTarget, vCursorPosition, vIntersectPosition);
						}
						else if (bCursorPressed)
						{
							pTargetObject->OnMouseDrag(pCollideTarget, vCursorPosition, vIntersectPosition, fTime);
						}
						else if (bCursorUp)
						{
							pTargetObject->OnMouseUp(pCollideTarget, vCursorPosition, vIntersectPosition);
						}
					}
					else if (m_pCoveredCollider != pCollideTarget && m_pCoveredCollider != NULL)
					{
						m_pCoveredCollider->OnMouseExit(m_pCoveredCollider, vCursorPosition, vIntersectPosition);
						pTargetObject->OnMouseEnter(pCollideTarget, vCursorPosition, vIntersectPosition);

						m_pCoveredCollider = pCollideTarget;

						if (bCursorDown)
						{
							pTargetObject->OnMouseDown(pCollideTarget, vCursorPosition, vIntersectPosition);
						}
						else if (bCursorPressed)
						{
							pTargetObject->OnMouseDrag(pCollideTarget, vCursorPosition, vIntersectPosition, fTime);
						}
						else if (bCursorUp)
						{
							pTargetObject->OnMouseUp(pCollideTarget, vCursorPosition, vIntersectPosition);
						}
					}
					else if (m_pCoveredCollider == NULL && pCollideTarget)
					{
						m_pCoveredCollider = pCollideTarget;

						pTargetObject->OnMouseEnter(pCollideTarget, vCursorPosition, vIntersectPosition);

						if (bCursorDown)
						{
							pTargetObject->OnMouseDown(pCollideTarget, vCursorPosition, vIntersectPosition);
						}
						else if (bCursorPressed)
						{
							pTargetObject->OnMouseDrag(pCollideTarget, vCursorPosition, vIntersectPosition, fTime);
						}
						else if (bCursorUp)
						{
							pTargetObject->OnMouseUp(pCollideTarget, vCursorPosition, vIntersectPosition);
						}
					}
				}

				SAFE_RELEASE(pTargetObject);
			}
			else
			{
				if (m_pCoveredCollider)
				{
					CGameObject* pTargetObject = m_pCoveredCollider->GetGameObject();
					pTargetObject->OnMouseExit(m_pCoveredCollider, vCursorPosition, vIntersectPosition);

					if (bCursorDown)
					{
						pTargetObject->OnMouseDown(m_pCoveredCollider, vCursorPosition, vIntersectPosition);
					}
					else if (bCursorPressed)
					{
						pTargetObject->OnMouseDrag(m_pCoveredCollider, vCursorPosition, vIntersectPosition, fTime);
					}
					else if (bCursorUp)
					{
						pTargetObject->OnMouseUp(m_pCoveredCollider, vCursorPosition, vIntersectPosition);
					}

					SAFE_RELEASE(pTargetObject);
					m_pCoveredCollider = NULL;
				}
			}
		}

		SAFE_RELEASE(pCameraTransform);
		SAFE_RELEASE(pCamera);
	}
}
#pragma endregion




#pragma region 3D
	{
		unordered_map<Vector3, CCollisionVoxel3D*>::iterator iter;
		unordered_map<Vector3, CCollisionVoxel3D*>::iterator iterEnd = m_mapCollisionVoxel3D.end();

		for (iter = m_mapCollisionVoxel3D.begin(); iter != iterEnd; )
		{
			size_t iCount = (*iter).second->GetContainedColliderCount();

			if (iCount == 0)
			{
				delete (*iter).second;
				iter = m_mapCollisionVoxel3D.erase(iter);
				continue;
			}
			else
			{
				//�� �浹ü���� �浹�ϰ�, �Լ� ȣ�� ����
				unordered_map<CCollider*, CCollider*>::iterator iterA = (*iter).second->GetContainedColliders()->begin();
				unordered_map<CCollider*, CCollider*>::iterator iterB = (*iter).second->GetContainedColliders()->begin();
				unordered_map<CCollider*, CCollider*>::iterator iterAEnd = (*iter).second->GetContainedColliders()->end();
				unordered_map<CCollider*, CCollider*>::iterator iterBEnd = (*iter).second->GetContainedColliders()->end();

				--iterAEnd;
				//O(n * (n / 2))
				for (; iterA != iterAEnd; ++iterA)
				{
					iterB = ++iterA;
					--iterA;
					for (; iterB != iterBEnd; ++iterB)
					{
						CCollider* pColliderA = (*iterA).second;
						CCollider* pColliderB = (*iterB).second;

						if (!pColliderA || !pColliderB || !pColliderA->IsEnable() || !pColliderB->IsEnable())
						{
							continue;
						}

						CGameObject* pGameObjectA = pColliderA->GetGameObject();
						CGameObject* pGameObjectB = pColliderB->GetGameObject();

						CGameObject* RootA = pGameObjectA->GetRoot();
						CGameObject* RootB = pGameObjectB->GetRoot();

						CLayer* pLayerA = pGameObjectA->GetLayer();
						CLayer* pLayerB = pGameObjectB->GetLayer();

						if (RootA != RootB)
						{
							if (pScene->GetLayerCollision(pLayerA, pLayerB))
							{
								bool isCollide = pColliderA->CollisionCheck(pColliderB);
								bool wasCollided = pColliderA->ContainCollision(pColliderB);

								if (isCollide && !wasCollided)
								{						
									RootA->CollisionEnterAll(pColliderA, pColliderB, fTime);
									RootB->CollisionEnterAll(pColliderB, pColliderA, fTime);

									//pGameObjectA->OnCollisionEnter(pColliderA, pColliderB, fTime);
									//pGameObjectB->OnCollisionEnter(pColliderB, pColliderA, fTime);
									
									pColliderA->AddCollisionList(pColliderB);
									pColliderB->AddCollisionList(pColliderA);
								}
								else if (isCollide && wasCollided)
								{
									RootA->CollisionStayAll(pColliderA, pColliderB, fTime);
									RootB->CollisionStayAll(pColliderB, pColliderA, fTime);

									//pGameObjectA->OnCollisionStay(pColliderA, pColliderB, fTime);
									//pGameObjectB->OnCollisionStay(pColliderB, pColliderA, fTime);

									pColliderA->AddCollisionList(pColliderB);
									pColliderB->AddCollisionList(pColliderA);
								}
								else if (!isCollide && wasCollided)
								{
									RootA->CollisionExitAll(pColliderA, pColliderB, fTime);
									RootB->CollisionExitAll(pColliderB, pColliderA, fTime);

									//pGameObjectA->OnCollisionExit(pColliderA, pColliderB, fTime);
									//pGameObjectB->OnCollisionExit(pColliderB, pColliderA, fTime);

									pColliderA->RemoveTargetFromCollisionList(pColliderB);
									pColliderB->RemoveTargetFromCollisionList(pColliderA);
								}
							}
						}

						SAFE_RELEASE(pLayerA);
						SAFE_RELEASE(pLayerB);
						SAFE_RELEASE(pGameObjectA);
						SAFE_RELEASE(pGameObjectB);
					}
				}
				++iter;
			}
		}
	}
#pragma endregion



	

	SAFE_RELEASE(pScene);
	
	return 0;
}
